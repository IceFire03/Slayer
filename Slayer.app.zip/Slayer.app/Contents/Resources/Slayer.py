# "slayer" and all applicable data and software is intellectual property of IceFire03#0300 (850446900209516594)
# You may not copy, distribute, sell, lease, or sublicense any property enclosed in this app.
# These actions are legally applicable to infringing on the intellectual property rights of IceFire03#0300
# and may cause legal action.
# -------------------------------
# DONT LOOK AT THE CODE IF YOU DONT WANT SPOILERS
import os
import random
import time
import tkinter as Tk
from random import randrange
from time import sleep
dt = False
if dt is False:
    window = Tk.Tk()
    window.config(bg="black")
    window.geometry('750x150')
    window.title("How to start Slayer")
    if os.name == "posix":
        Tk.Label(window,
                 text="CLOSE THIS WINDOW IF YOU HAVE FOLLOWED THE BELOW STEPS TO START THE GAME\n"
                 "If you are not on MacOs, your way to access terminal may differ.\nTo begin the game:\n"
                 "Open terminal\n(command + space, and enter in terminal)\n"
                 "copy and paste in the below and hit enter! make sure there are no spaces in the file directory.\n"
                 "(triple click, cmd + c, click the terminal window, cmd + v)",
                 fg="white", bg="black").pack()
    else:
        Tk.Label(window,
                 text="CLOSE THIS WINDOW IF YOU HAVE FOLLOWED THE BELOW STEPS TO START THE GAME\n"
                 "If you are not on Windows, your way to access terminal may differ.\nTo begin the game in Windows:\n"
                 "Open a command-line\n(windows key + x, select command prompt)\n"
                 "copy and paste in the below and hit enter! make sure there are no spaces in the file directory.\n"
                 "(triple click, ctrl + c, click the terminal window, ctrl + v)",
                 fg="white", bg="black").pack()
    ent = Tk.Entry(window, state='readonly', readonlybackground='black', fg='white')
    var = Tk.StringVar()
    var.set("python3 " + os.path.abspath(__file__))
    ent.config(textvariable=var, relief='flat')
    ent.pack()
    window.lift()
    print('Close the "How to start Slayer" window to begin the game in this window!')
    window.mainloop()
else:
    print("\n\n TURN\n OFF\n DEVTOOLS\n BEFORE\n RELEASE\n\n")
sdl = os.path.abspath(__file__)
sdl = sdl[0:int(len(sdl) - 9)]
sdl = str(sdl) + "savedata.txt"
dragonbeaten = 0
willpower = 0
dmg = 0
dungdone = 0
souls = 0
bountyready = 0
inventory = []
dlevel = 0
dxp = 0
checkinv = []
division = "Swordsman"
subdivision = "Wielder"
basehp = 100
gem = "None"
shield = 1
knownattacks = []
knowndefenses = []
shopitems = {'BASIC SWORD': 500, 'BROAD SWORD': 25000, 'PAPER SWORD': 125000, 'GLASS SWORD': 1000000,
             'GOLDEN SWORD': 10000000, 'BASIC SHIELD': 500, 'BANDED SHIELD': 25000, 'STEEL SHIELD': 125000,
             'TITANIUM SHIELD': 1000000, 'GOLDEN SHIELD': 10000000, 'BASIC BOW': 500, 'SLENDER BOW': 25000,
             'STRONG BOW': 125000, 'ELDER BOW': 1000000, 'GOLDEN BOW': 10000000, 'BASIC STAFF': 500, 'OAK STAFF': 25000,
             'SPRUCE STAFF': 125000, 'EBONY STAFF': 1000000, 'GOLDEN STAFF': 10000000, 'PLAINS RING': 1000,
             'MOUNTAIN RING': 35000, 'CAVE RING': 200000, "KING'S RING": 500000, 'MYSTERY KEY': 750000,
             'BASIC ARMOR': 500, 'LEATHER ARMOR': 25000, 'COPPER ARMOR': 125000, 'TITANIUM ARMOR': 1000000,
             'GOLDEN ARMOR': 10000000}
rubyitems = {'LAMP OIL': 50, 'ROPE': 100, 'BOMB': 5}
level = int(1)
totalxp = int(1)
totalgold = int(1)
totalrubees = int(0)
area = "PLAINS"
mountainsunlocked = 0
cavesunlocked = 0
graveyardunlocked = 0
castleunlocked = 0
lsc = 10
tslh = time.time()
tslq = 1200
bountydescriptions = {1: "Kill a goliath", 2: "Reclaim stolen treasure", 3: "Get potion parts",
                      4: "Trolls attacking caravans", 5: "Young dragon terrorizing mountain village",
                      6: "Fruit gatherer needed", 7: "Take a quiz", 8: "Chest verifier needed", 9: "Food shortage"}
bountydefinitions = {
    1: "A goliath has been spotted in the mountains! It is en route to attack the village.. Please kill it for me!\n"
       ">> You camp out by the village, and hear the goliath approaching..",
    2: "A huge swarm of goblins stole my treasure! Please get it for me!\n"
       ">> You go to the location marked on the bounty..",
    3: "I need you to hunt down a slime boss for potion parts!\n>> You search for a boss slime..",
    4: "A group of trolls is repeatedly attacking supply shipments. Please take them down!\n"
       ">> You follow and guard the caravans..",
    5: "Please vanquish the dragon!\n>> You go to the location marked on the map..",
    6: "Please gather fruit from a dangerous area!\n>> You go to the area marked on the bounty..",
    7: "Take a quick quiz and you will be rewarded!\n>> You go to the area marked on the bounty..",
    8: "Please help me test these chests for mimics!\n>> You go to the bounty area and check the chests..",
    9: "The village is starving! Please kill a buffalo for food."}
bountymonsters = {1: "the GOLIATH", 2: "the GOBLIN HORDE", 3: "a SLIME BOSS", 4: "the TROLL RAIDERS",
                  5: "a DRAGON CHILD", 6: "a FRUITARIAN WEREWOLF", 7: "nothing lol", 8: "a MIMIC", 9: "a BUFFALO"}
choosingdivision = 0
plainsmonsters = "a boar,a hyena,a jackal,a slime,an ogre,a swarm of bees,a troll,an evil cat,a zombie," \
                 "a wearwolf,a wherewolf,a werewolf,a we'rewolf,a skeleton"
mountainmonsters = "bigfoot,an orc,a mountain dragon,a snow leopard,an adamantine golem, an arctic dwarf," \
                   "an ice troll,an ice bat,a giant lizard,a cloud elemental"
cavemonsters = "a bat swarm,a vampire bat,a giant beetle,a cave troll,a one eyed troll,a scurrybug," \
               "a rock goblin,a recluse, a drow,a darkmantle,a crystal cryptid,a moss cryptid,a dark cryptid"
graveyardmonsters = "an undead,and infernal,a ghost,a necromancer,a flame spirit,a grim reaper," \
                    "a wyrm,a spider queen,an arachnid amalgamation"
castlemonsters = "a guardsman troop,a bowsman troop,a collossus,a legion,a sword wraith swarm,a giant gargoyle," \
                 "a banshee soul,a manticore,a kingsman,a raider squadron"
print("Welcome to slayer!\n[V1.7.0 (beta)]\n----\nPlease wait for bootup......")


def load():
    global totalgold
    global totalrubees
    global level
    global totalxp
    global dxp
    global gem
    global mountainsunlocked
    global cavesunlocked
    global graveyardunlocked
    global castleunlocked
    loadline = input("What is the save slot number of your save file? "
                     "(Or say CC for a cross-version transfer.)\n> ").upper()
    if loadline == "CC":
        inp = input("Load your save on a previous version and say CC during SAVE to get a file directory.\n "
                    "Copy and paste that into here!\n> ")
        with open(inp, 'r') as file:
            savedata = file.readlines()
        with open(sdl, 'w') as file:
            file.writelines(savedata)
            print("Saves transferred.")
            return
    else:
        try:
            with open(sdl, 'r') as file:
                loadcode = file.readlines()[int(loadline)]
        except:
            print("That isn't a save slot!")
            return
        if loadcode == '\n':
             print("That save slot has no data!")
             return
    totalgold = int(loadcode[0:10])
    totalrubees = int(loadcode[10:17])
    level = int(loadcode[17:22])
    totalxp = int(loadcode[22:30])
    dxp = int(loadcode[39:46])
    mountainsunlocked = int(loadcode[46])
    cavesunlocked = int(loadcode[47])
    graveyardunlocked = int(loadcode[48])
    castleunlocked = int(loadcode[49])
    try:
        gem = str(loadcode[50])
    except:
        gem = "None"
    if gem == "0":
        gem = "None"
    elif gem == "1":
        gem = "RUBY"
    elif gem == "2":
        gem = "AQUAMARINE"
    elif gem == "3":
        gem = "EMERALD"
    print("Save data loaded!\nNow, choose your class.")


def save():
    global mountainsunlocked
    global cavesunlocked
    global graveyardunlocked
    global castleunlocked
    global level
    global totalxp
    global totalgold
    global totalrubees
    global gem
    global dlevel
    global dxp
    global basehp
    global maxhp
    global baseatk
    global basedef
    global area
    save = ""
    print("INVENTORY IS NOT SAVED. Make sure to sell items before saving!")
    if totalgold < 9999999999:
        savegold = totalgold
    else:
        savegold = 999999999
    x = 10 - len(str(totalgold))
    for i in range(x):
        savegold = str(0) + str(savegold)
    save += str(savegold)
    if totalrubees < 9999999:
        saverubees = totalrubees
    else:
        saverubees = 999999999
    x = 7 - len(str(totalrubees))
    for i in range(x):
        saverubees = str(0) + str(saverubees)
    save += saverubees
    if level < 99999:
        savelevel = level
    else:
        savelevel = 99999
    x = 5 - len(str(level))
    for i in range(x):
        savelevel = str(0) + str(savelevel)
    save += savelevel
    if totalxp < 99999999:
        savexp = totalxp
    else:
        savexp = 99999999
    x = 8 - len(str(savexp))
    for i in range(x):
        savexp = str(0) + str(savexp)
    save += str(savexp)
    save += str(basehp)
    if len(str(baseatk)) == 2:
        saveatk = str(0) + str(baseatk)
    else:
        saveatk = baseatk
    save += str(saveatk)
    if len(str(basedef)) == 2:
        savedef = str(0) + str(basedef)
    else:
        savedef = str(basedef)
    save += str(savedef)
    if dxp < 9999999:
        savedxp = dxp
    else:
        savedxp = 9999999
    x = 7 - len(str(savedxp))
    for i in range(x):
        savedxp = str(0) + str(savedxp)
    save += str(savedxp)
    save += str(mountainsunlocked)
    save += str(cavesunlocked)
    save += str(graveyardunlocked)
    save += str(castleunlocked)
    if gem == "None":
        save += 0
    elif gem == "RUBY":
        save += 1
    elif gem == "AQUAMARINE":
        save += 2
    elif gem == "EMERALD":
        save += 3
    save += str(0)
    save += str(0)
    saveline = input("Type in a numerical line for your save file (max 10), or DELETE to delete a save.\nType CC to save data to a newer game version.\n> ")
    if saveline.upper() == "DELETE":
        print("Save slots:")
        lookup = '0'
        with open(sdl) as myFile:
            for num, line in enumerate(myFile, 1):
                if lookup in line:
                    print(num)
        dkey = input("What save slot should be deleted?\n> ")
        try:
            with open(sdl, 'r') as file:
                savedata = file.readlines()
                savedata[int(dkey)] = ""
            with open(sdl, 'w') as file:
                file.writelines(savedata)
                print("Save deleted.")
                return
        except:
            print("Failed, make sure to input the correct line!")
            return
    elif saveline.upper() == "CC":
        print("To transfer saves, open the game on the newer version, enter CC, and paste in the below:\n" + sdl)
        return
    elif int(saveline) > 11:
        print("You can only have up to 10 save slots!")
        return
    else:
        try:
            amongus = int(saveline)
            amongus += 1
            amongus -= 1
        except:
            print("Not a valid number!")
            return
        with open(sdl, 'r') as file:
            data = file.readlines()
            data[int(saveline)] = save + '\n'
        with open(sdl, 'w') as file:
            file.writelines(data)
            print("Saved!")
while choosingdivision == 0:
    inp = input(
        "Pick a division!\nSWORDSMAN - Uses swords to slay foes.\nMAGE - Channels magic through staffs.\n"
        "DEFENDER - Bludgeons enemies with shields and armor. Extra defense from armor.\n"
        "ARCHER - Uses bows and arrows to shoot down monsters.\n(say LOAD to load a save file)\n> ")
    inp = inp.upper()
    division = inp
    if inp == "ARCHER":
        inp = input("Choose a subdivision! or BACK\nRAPID ARCHER - Fires quickly. 40x3 Attack, 75 defense, 135 health\n"
                    "LONGBOW ARCHER - Fires a slow and powerful shot. 100 Attack, 50 defense, 100 health\n"
                    "SNIPER - Super accurate. 80 attack, 70 defense, 100 health.\n> ")
        inp = inp.upper()
        if inp == "RAPID ARCHER":
            subdivision = "RAPID ARCHER"
            knownattacks += ["SHOT"]
            knowndefenses += ["DODGE"]
            baseatk = 40
            basedef = 75
            basehp = 135
            basemp = 0
            choosingdivision = 1
        elif inp == "LONGBOW ARCHER":
            subdivision = "LONGBOW ARCHER"
            knownattacks += ["SHOT"]
            knowndefenses += ["DODGE"]
            baseatk = 100
            basedef = 50
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "SNIPER":
            subdivision = "SNIPER"
            knownattacks += ["SHOT"]
            knowndefenses += ["DODGE"]
            baseatk =  80
            basedef = 70
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            print("That isn't a subdivision!")
    elif inp == "MAGE":
        inp = input(
            "Choose a subdivision! or BACK\nCLERIC - Bonus to healing. 40 Attack, 40 defense, 180 health. 150 mp.\n"
            "WIZARD - Bonus to damaging spells. 120 Attack, 30 defense, 100 health. 125 mp.\n"
            "WARLOCK - Bonus to infliction spells. 80 attack, 70 defense, 100 health. 150 mp.\n> ")
        inp = inp.upper()
        if inp == "CLERIC":
            subdivision = "CLERIC"
            knownattacks += ["BOLT"]
            baseatk = 40
            basedef = 40
            basehp = 180
            basemp = 150
            choosingdivision = 1
        elif inp == "WIZARD":
            subdivision = "WIZARD"
            knownattacks += ["BOLT"]
            baseatk = 120
            basedef = 30
            basehp = 100
            basemp = 145
            choosingdivision = 1
        elif inp == "WARLOCK":
            subdivision = "WARLOCK"
            knownattacks += ["BOLT"]
            baseatk = 80
            basedef = 70
            basehp = 100
            basemp = 150
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            print("That isn't a subdivision!")
    elif inp == "SWORDSMAN":
        inp = input(
            "Choose a subdivision! or BACK\nNINJA - Has a chance to dodge attacks. 60 Attack, 50 defense, 100 health\n"
            "WIELDER - The classic swordsman. 90 Attack, 90 defense, 90 health\n"
            "BRUTE - Charges attacks to deal triple damage. 40 attack, 120 defense, 110 health\n> ")
        inp = inp.upper()
        if inp == "NINJA":
            subdivision = "NINJA"
            knownattacks += ["SLICE"]
            knowndefenses += ["CLASH"]
            baseatk = 60
            basedef = 50
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "WIELDER":
            subdivision = "WIELDER"
            knownattacks += ["SLICE"]
            knowndefenses += ["CLASH"]
            baseatk = 90
            basedef = 90
            basehp = 90
            basemp = 0
            choosingdivision = 1
        elif inp == "BRUTE":
            subdivision = "BRUTE"
            knownattacks += ["SLICE"]
            knowndefenses += ["CLASH"]
            baseatk = 40
            basedef = 120
            basehp = 110
            basemp = 0
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            print("That isn't a subdivision!")
    elif inp == "DEFENDER":
        inp = input(
            "Choose a subdivision! or BACK\nSPIKER - Spikes shields for more damage. 50 Attack, 150 defense, 100 health\n"
            "BULKER - A super resistant defender. 25 Attack, 200 defense, 130 health\n"
            "REFLECTOR - Uses reflective shields to minimize inflictions and reflect some attacks. 40 attack, 120 defense, 160 health\n> ")
        inp = inp.upper()
        if inp == "SPIKER":
            subdivision = "SPIKER"
            knownattacks += ["SHIELD BASH"]
            knowndefenses += ["BLOCK"]
            baseatk = 50
            basedef = 150
            basehp = 110
            basemp = 0
            choosingdivision = 1
        elif inp == "BULKER":
            subdivision = "BULKER"
            knownattacks += ["SHIELD BASH"]
            knowndefenses += ["BLOCK"]
            baseatk = 25
            basedef = 200
            basehp = 130
            basemp = 0
            choosingdivision = 1
        elif inp == "REFLECTOR":
            subdivision = "REFLECTOR"
            knownattacks += ["SHIELD BASH"]
            knowndefenses += ["BLOCK"]
            baseatk = 45
            basedef = 120
            basehp = 160
            basemp = 0
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            print("That isn't a subdivision!")
    elif inp == "LOAD":
        load()
    else:
        print("That isn't a division.")
try: division
except NameError:
    print("failed to set your division. set division to Swordsman..")
    division = "SWORDSMAN"
try: subdivision
except NameError:
    print("failed to set your subdivision. set division to Wielder..")
    subdivision = "WIELDER"
print("You set your division to " + str(division) + " and your subdivision to " + str(subdivision) + ".")
if dt is False:
    sleep(1)
    print("Welcome to Slayer!")
    sleep(1)
    print("Say 'guide' for a guide, or HELPME for a list of commands.")
    sleep(1)
maxhp = basehp
currenthp = maxhp
def jshop():
    global inventory
    global gem
    global totalgold
    global totalrubees
    if "GOLDEN BOW" in inventory or "GOLDEN SHIELD" in inventory or "GOLDEN STAFF" in inventory or "GOLDEN SWORD" in inventory:
        if "GOLDEN BOW" in inventory:
            print("Welcome to the Enhancement Shop! Here you can add a gem to golden weapons.")
            print("I see you have a GOLDEN BOW! Here are some gems for the bow..")
            print("RUBY == 1 ruby, 10000 gold: + 10% attack")
            print("AQUAMARINE == 100 rubees, 100000 gold: + 40% attack")
            print("EMERALD == 1000 rubees, 1000000 gold: + 75% attack")
            inp = input("Use FUSE to fuse a gem, REMOVE to remove one, and QUIT to leave.\n> ")
        elif "GOLDEN SHIELD" in inventory:
            print("Welcome to the Enhancement Shop! Here you can add a gem to golden weapons.")
            print("I see you have a GOLDEN SHIELD! Here are some gems for the shield..")
            print("RUBY == 1 ruby, 10000 gold: + 10% attack")
            print("AQUAMARINE == 100 rubees, 100000 gold: + 40% attack")
            print("EMERALD == 1000 rubees, 1000000 gold: + 75% attack")
            inp = input("Use FUSE to fuse a gem, REMOVE to remove one, and QUIT to leave.\n> ")
        elif "GOLDEN STAFF" in inventory:
            print("Welcome to the Enhancement Shop! Here you can add a gem to golden weapons.")
            print("I see you have a GOLDEN STAFF! Here are some gems for the staff..")
            print("RUBY == 1 ruby, 10000 gold: + 10% attack")
            print("AQUAMARINE == 100 rubees, 100000 gold: + 40% attack")
            print("EMERALD == 1000 rubees, 1000000 gold: + 75% attack")
            inp = input("Use FUSE to fuse a gem, REMOVE to remove one, and QUIT to leave.\n> ")
        elif "GOLDEN SWORD" in inventory:
            print("Welcome to the Enhancement Shop! Here you can add a gem to golden weapons.")
            print("I see you have a GOLDEN SWORD! Here are some gems for the sword..")
            print("RUBY == 1 ruby, 10000 gold: + 10% attack")
            print("AQUAMARINE == 100 rubees, 100000 gold: + 40% attack")
            print("EMERALD == 1000 rubees, 1000000 gold: + 75% attack")
            inp = input("Use FUSE to fuse a gem, REMOVE to remove one, and QUIT to leave.\n> ")
        else:
            inp = "QUIT" 
        inp = inp.upper()
        if inp == "FUSE":
            if gem == "None":
                inp = input("What gem would you like to fuse on?\n> ").upper()
                if inp == "RUBY":
                    if totalgold >= 10000 and totalrubees > 0:
                        totalgold -= 10000
                        totalrubees -= 1
                        print("You fused on a RUBY!")
                        gem = "RUBY"
                    else:
                        print(f"You don't have the required items!\n({totalgold})/10000 | {totalrubees}/1")
                elif inp == "AQUAMARINE":
                    if totalgold >= 100000 and totalrubees >= 100:
                        totalgold -= 100000
                        totalrubees -= 100
                        print("You fused on an AQUAMARINE!")
                        gem = "AQUAMARINE"
                    else:
                        print(f"You don't have the required items!\n({totalgold})/100000 | {totalrubees}/100")
                elif inp == "EMERALD":
                    if totalgold >= 1000000 and totalrubees >= 1000:
                        totalgold -= 1000000
                        totalrubees -= 1000
                        print("You fused on an EMERALD!")
                        gem = "EMERALD"
                    else:
                        print(f"You don't have the required items!\n({totalgold})/1000000 | {totalrubees}/1000")
                else:
                    print("That isn't a gem!")
            else:
                print(f"You already have the {gem} fused to your weapon!")
            updatestats()
        elif inp == "REMOVE":
            if gem == "None":
                print("You don't have a gem to remove!")
            else:
                if input(f"Are you sure you want to remove your {gem}? (yes/no)\n> ").upper() == "YES":
                    print(f"Your {gem} was removed!")
                    gem = "None"
        elif inp == "QUIT":
            print("You left the enhancement shop.")
        else:
            print("You can't do that!")
            print("You left the enhancement shop.")
    else:
        print("You can't enhance such a bad weapon. Come back with a GOLDEN weapon!")
def updatestats():
    global dlevel
    global weapon
    global maxhp
    global dxp
    global knownattacks
    global knowndefenses
    global gem
    global level
    global currenthp
    global basehp
    global baseatk
    global basedef
    global basemp
    global armor
    global maxmp
    global armor
    global currentmp
    global inventory
    global defense
    global attack
    global tslh
    global subdivision
    global aim
    maxhp = ((level - 1) * 10) + basehp
    if subdivision == "CLERIC":
        currenthp += round(int(time.time() - tslh) * 20)
    else:
        currenthp += round(int(time.time() - tslh) * 10)
    tslh = time.time()
    if division == "MAGE":
        maxmp = ((level - 1) * 10) + basemp
    else:
        maxmp = 0
    tslh = time.time()
    if currenthp > maxhp:
        currenthp = maxhp
    if currenthp < 0:
        currenthp = 0
    weapon = 1
    shield = 1
    sflag = False
    if "ARMOR" in str(inventory):
        if "BASIC ARMOR" in inventory:
            armor = 1.5
        elif "LEATHER ARMOR" in inventory:
            armor = 2
        elif "COPPER ARMOR" in inventory:
            armor = 3
        elif "TITANIUM ARMOR" in inventory:
            armor = 5
        elif "GOLDEN ARMOR" in inventory:
            armor = 10
    else:
        armor = 1
    if "SWORD" in str(inventory):
        if "BASIC SWORD" in inventory:
            weapon = 1.5
            shield = 1
        elif "BROAD SWORD" in inventory:
            weapon = 2
            shield = 1
        elif "PAPER SWORD" in inventory:
            weapon = 3
            shield = 1
        elif "GLASS SWORD" in inventory:
            weapon = 5
            shield = 1
        elif "GOLDEN SWORD" in inventory:
            weapon = 10
            shield = 1
    elif "STAFF" in str(inventory):
        if "BASIC STAFF" in inventory:
            weapon = 1.5
            shield = 1
        elif "OAK STAFF" in inventory:
            weapon = 2
            shield = 1
        elif "SPRUCE STAFF" in inventory:
            weapon = 3
            shield = 1
        elif "EBONY STAFF" in inventory:
            weapon = 5
            shield = 1
        elif "GOLDEN STAFF" in inventory:
            weapon = 10
            shield = 1
    elif "SHIELD" in str(inventory):
        sflag = True
        if "BASIC SHIELD" in inventory:
            weapon = 1
            shield = 1.25
        elif "BANDED SHIELD" in inventory:
            weapon = 1.5
            shield = 1.75
        elif "STEEL SHIELD" in inventory:
            weapon = 2
            shield = 2.5
        elif "TITANIUM SHIELD" in inventory:
            weapon = 3
            shield = 2.25
        elif "GOLDEN SHIELD" in inventory:
            weapon = 5
            shield = 3.75
    elif "BOW" in str(inventory):
        if "BASIC BOW" in inventory:
            weapon = 1.5
            shield = 1
        elif "SLENDER BOW" in inventory:
            weapon = 2
            shield = 1
        elif "STRONG BOW" in inventory:
            weapon = 3
            shield = 1
        elif "ELDER BOW" in inventory:
            weapon = 5
            shield = 1
        elif "GOLDEN BOW" in inventory:
            weapon = 10
            shield = 1
    if gem == "None":
        gmult = 1
    elif gem == "RUBY":
        gmult = 1.1
    elif gem == "AQUAMARINE":
        gmult = 1.4
    elif gem == "EMERALD":
        gmult = 1.7
    else:
        gmult = 1
        print("weird error.. your gem is glitched, I set it to none."
              " Contact Ice on the discord server if you need help.")
    attack = round(((baseatk + ((level - 1) * 5)) * weapon) * gmult)
    defense = round((basedef + ((level - 1) * 5)) * armor) * shield
    if sflag == True:
        defense = round(defense * gmult)
    prevdlevel = dlevel
    if dxp > 100:
        dlevel = 1
        if dxp > 300:
            dlevel = 2
            if dxp > 900:
                dlevel = 3
                if dxp > 2700:
                    dlevel = 4
                    if dxp > 8100:
                        dlevel = 5
                        if subdivision == "RAPID ARCHER":
                            knownattacks = ["SHOT", "TURBOBURST", "MARK"]
                            knowndefenses = ["DASH"]
                        elif subdivision == "LONGBOW ARCHER":
                            knownattacks = ["RAILGUN", "CHARGE", "MARK"]
                            knowndefenses = ["DODGE"]
                        elif subdivision == "SNIPER":
                            knownattacks = ["AMBUSH SNIPE", "LOCK ON"]
                            knowndefenses = ["DODGE"]
                        elif subdivision == "CLERIC":
                            knownattacks = ["BOLT", "LIFEBEAM", "EMBER"]
                            knowndefenses = ["GUARDIAN SHIELD"]
                        elif subdivision == "WIZARD":
                            knownattacks = ["FINALE PULSE", "EMBER", "HEAL"]
                            knowndefenses = []
                        elif subdivision == "WARLOCK":
                            knownattacks = ["BOLT", "SUPERSTORM", "HEAL"]
                            knowndefenses = []
                        elif subdivision == "NINJA":
                            knownattacks = ["SHADOW CLONE", "SMOKE BOMB", "SURPRISE ATTACK"]
                            knowndefenses = ["SHADOW CLASH"]
                        elif subdivision == "WIELDER":
                            knownattacks = ["SLASH", "GUILLOTINE"]
                            knowndefenses = ["PARRY"]
                        elif subdivision == "BRUTE":
                            knownattacks = ["CLEAVE", "FOCUS POWER", "CHARGE"]
                            knowndefenses = ["POWER CLASH"]
                        elif subdivision == "SPIKER":
                            knownattacks = ["SPIKE SPEW", "SHARPEN"]
                            knowndefenses = ["THORN BLOCK"]
                        elif subdivision == "BULKER":
                            knownattacks = ["SHIELD COMBO", "MASTER GUARD"]
                            knowndefenses = ["COUNTER", "GUARD"]
                        elif subdivision == "REFLECTOR":
                            knownattacks = ["SUN'S SURFACE", "COMBO PUNCH"]
                            knowndefenses = ["BLOCK", "SHINE", "PRISM SHIELD"]
                    elif subdivision == "RAPID ARCHER":
                        knownattacks = ["SHOT", "BURST", "MARK"]
                        knowndefenses = ["DASH"]
                    elif subdivision == "LONGBOW ARCHER":
                        knownattacks = ["SHARPSHOOT", "CHARGE SHARPSHOT", "CHARGE", "MARK"]
                        knowndefenses = ["DODGE"]
                    elif subdivision == "SNIPER":
                        knownattacks = ["SHARPSHOOT", "LOCK ON"]
                        knowndefenses = ["DODGE"]
                    elif subdivision == "CLERIC":
                        knownattacks = ["BOLT", "HEAL", "EMBER"]
                        knowndefenses = ["GUARDIAN SHIELD"]
                    elif subdivision == "WIZARD":
                        knownattacks = ["BEAM", "EMBER", "HEAL"]
                        knowndefenses = []
                    elif subdivision == "WARLOCK":
                        knownattacks = ["BOLT", "EMBER", "FROST", "HEAL"]
                        knowndefenses = []
                    elif subdivision == "NINJA":
                        knownattacks = ["SLICE", "SMOKE BOMB", "SURPRISE ATTACK"]
                        knowndefenses = ["SHADOW CLASH"]
                    elif subdivision == "WIELDER":
                        knownattacks = ["SLASH", "FINISHER"]
                        knowndefenses = ["PARRY"]
                    elif subdivision == "BRUTE":
                        knownattacks = ["POWER SLASH", "FOCUS POWER", "CHARGE"]
                        knowndefenses = ["POWER CLASH"]
                    elif subdivision == "SPIKER":
                        knownattacks = ["SPIKED SHIELD BASH", "SHARPEN"]
                        knowndefenses = ["THORN BLOCK"]
                    elif subdivision == "BULKER":
                        knownattacks = ["SHIELD COMBO"]
                        knowndefenses = ["COUNTER", "GUARD"]
                    elif subdivision == "REFLECTOR":
                        knownattacks = ["SHIELD BASH", "COMBO PUNCH"]
                        knowndefenses = ["BLOCK", "SHINE", "PRISM SHIELD"]
                elif subdivision == "RAPID ARCHER":
                    knownattacks = ["SHOT", "BURST", "MARK"]
                    knowndefenses = ["DASH"]
                elif subdivision == "LONGBOW ARCHER":
                    knownattacks = ["SHARPSHOOT", "CHARGE SHOT", "CHARGE", "MARK"]
                    knowndefenses = ["DODGE"]
                elif subdivision == "SNIPER":
                    knownattacks = ["SHARPSHOOT", "LOCK ON"]
                    knowndefenses = ["DODGE"]
                elif subdivision == "CLERIC":
                    knownattacks = ["BOLT", "HEAL", "EMBER"]
                    knowndefenses = ["GUARDIAN SHIELD"]
                elif subdivision == "WIZARD":
                    knownattacks = ["BEAM", "EMBER", "HEAL"]
                    knowndefenses = []
                elif subdivision == "WARLOCK":
                    knownattacks = ["BOLT", "EMBER", "FROST", "HEAL"]
                    knowndefenses = []
                elif subdivision == "NINJA":
                    knownattacks = ["SLICE", "SMOKE BOMB", "SURPRISE ATTACK"]
                    knowndefenses = ["SHADOW CLASH"]
                elif subdivision == "WIELDER":
                    knownattacks = ["SLASH", "FINISHER"]
                    knowndefenses = ["PARRY"]
                elif subdivision == "BRUTE":
                    knownattacks = ["POWER SLICE", "CHARGE", "FOCUS POWER"]
                    knowndefenses = ["POWER CLASH"]
                elif subdivision == "SPIKER":
                    knownattacks = ["SPIKED SHIELD BASH", "SHARPEN"]
                    knowndefenses = ["THORN BLOCK"]
                elif subdivision == "BULKER":
                    knownattacks = ["SHIELD COMBO"]
                    knowndefenses = ["COUNTER", "GUARD"]
                elif subdivision == "REFLECTOR":
                    knownattacks = ["SHIELD BASH"]
                    knowndefenses = ["BLOCK", "SHINE", "PRISM SHIELD"]
            elif subdivision == "RAPID ARCHER":
                knownattacks = ["SHOT", "BURST", "MARK"]
                knowndefenses = ["DODGE"]
            elif subdivision == "LONGBOW ARCHER":
                knownattacks = ["SHOT", "CHARGE SHOT", "CHARGE", "MARK"]
                knowndefenses = ["DODGE"]
            elif subdivision == "SNIPER":
                knownattacks = ["SHOT", "LOCK ON"]
                knowndefenses = ["DODGE"]
            elif subdivision == "CLERIC":
                knownattacks = ["BOLT", "HEAL", "EMBER"]
                knowndefenses = []
            elif subdivision == "WIZARD":
                knownattacks = ["BEAM", "EMBER"]
                knowndefenses = []
            elif subdivision == "WARLOCK":
                knownattacks = ["BOLT", "EMBER", "FROST"]
                knowndefenses = []
            elif subdivision == "NINJA":
                knownattacks = ["SLICE", "SMOKE BOMB"]
                knowndefenses = ["SHADOW CLASH"]
            elif subdivision == "WIELDER":
                knownattacks = ["SLASH", "FINISHER"]
                knowndefenses = ["CLASH"]
            elif subdivision == "BRUTE":
                knownattacks = ["POWER SLICE", "FOCUS POWER", "CHARGE"]
                knowndefenses = ["CLASH"]
            elif subdivision == "SPIKER":
                knownattacks = ["SPIKED SHIELD BASH"]
                knowndefenses = ["THORN BLOCK"]
            elif subdivision == "BULKER":
                knownattacks = ["SHIELD COMBO"]
                knowndefenses = ["BLOCK", "GUARD"]
            elif subdivision == "REFLECTOR":
                knownattacks = ["SHIELD BASH", "PUNCH"]
                knowndefenses = ["BLOCK", "SHINE"]
        elif subdivision == "RAPID ARCHER":
            knownattacks = ["SHOT", "BURST"]
            knowndefenses = ["DODGE"]
        elif subdivision == "LONGBOW ARCHER":
            knownattacks = ["SHOT", "CHARGE SHOT", "CHARGE"]
            knowndefenses = ["DODGE"]
        elif subdivision == "SNIPER":
            knownattacks = ["SHOT", "MARK"]
            knowndefenses = ["DODGE"]
        elif subdivision == "CLERIC":
            knownattacks = ["BOLT", "HEAL"]
            knowndefenses = []
        elif subdivision == "WIZARD":
            knownattacks = ["BEAM"]
            knowndefenses = []
        elif subdivision == "WARLOCK":
            knownattacks = ["BOLT", "EMBER"]
            knowndefenses = []
        elif subdivision == "NINJA":
            knownattacks = ["SLICE", "SMOKE BOMB"]
            knowndefenses = ["CLASH"]
        elif subdivision == "WIELDER":
            knownattacks = ["SLASH"]
            knowndefenses = ["CLASH"]
        elif subdivision == "BRUTE":
            knownattacks = ["POWER SLICE", "CHARGE"]
            knowndefenses = ["CLASH"]
        elif subdivision == "SPIKER":
            knownattacks = ["SPIKED SHIELD BASH"]
            knowndefenses = ["BLOCK"]
        elif subdivision == "BULKER":
            knownattacks = ["SHIELD BASH"]
            knowndefenses = ["BLOCK", "GUARD"]
        elif subdivision == "REFLECTOR":
            knownattacks = ["SHIELD BASH"]
            knowndefenses = ["BLOCK", "SHINE"]
    if dlevel != prevdlevel:
        print("You leveled up in division!!\nCombat options :\n" + str(knownattacks) + "\n" + str(knowndefenses))
def startbounty():
    global division
    global subdivision
    global basehp
    global baseatk
    global basedef
    global basemp
    global tslq
    global bountydefinitions
    global bountyready
    global bounty
    global wonbounty
    global totalgold
    global dxp
    global dt
    print("You read the bounty board.")
    if (time.time() - tslq) > 1200 or dt is True:
        bountyready = 1
    else:
        print("There are no new bounties. Next bounty available in " + str(round(1200 - (time.time() - tslq))) + " seconds.")
        return
    if bountyready == 1:
        print("A bounty is available!")
        bounty = randrange(1, 10)
        print(bountydescriptions[bounty])
        inp = input("Would you like to begin the bounty? (YES/NO)\n> ")
        inp = inp.upper()
        if inp == "YES":
            print("You begin the bounty..")
            print(bountydefinitions[bounty])
            input("Press enter to continue.")
            fight()
            if wonbounty == 1:
                gdxp = randrange(75, 201)
                if bounty == 1:
                    gg = randrange(1, 6)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print("You defeated the goliath! You gained " + str(gdxp) + " division experience and " + str(gg) + " gold!")
                    dxp += gdxp
                elif bounty == 2:
                    gdxp += 50
                    gg = randrange(2, 8)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(f"You defeated the goblins! You gained {gdxp} division experience and got {gg} gold!")
                    dxp += gdxp
                elif bounty == 3:
                    gg = randrange(7, 11)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(
                        f"You defeated the slime boss! You gained {gdxp} division experience. "
                        f"You gave the monster parts and got {gg} gold!")
                    dxp += gdxp
                elif bounty == 4:
                    gdxp += 25
                    gg = randrange(1, 6)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(f"You defeated the trolls! You gained {gdxp} division experience. You were paid {gg} gold!")
                    dxp += gdxp
                elif bounty == 5:
                    gdxp += 25
                    gg = randrange(1, 3)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(f"You defeated the dragon! You gained {gdxp} division experience. You were paid {gg} gold!")
                    dxp += gdxp
                elif bounty == 6:
                    gdxp += 10
                    gg = randrange(10, 16)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(
                        f"You defeated the werewolf! You gained {gdxp} division experience. "
                        f"You were paid {gg} gold for the fruit!")
                    dxp += gdxp
                elif bounty == 7:
                    gdxp = 0
                    gg = randrange(15, 26)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(f"You won the quiz! you were paid {gg} gold.")
                    dxp += gdxp
                elif bounty == 8:
                    gg = randrange(9, 26)
                    beforegold = totalgold
                    totalgold = round(totalgold * (1 + (0.01 * gg))) + 100
                    gg = totalgold - beforegold + 100
                    print(f"You defeated the mimic! You gained {gdxp} division experience. You were paid {gg} gold!")
                    dxp += gdxp
                elif bounty == 9:
                    gdxp = round(gdxp * 1.5)
                    gg = randrange(2, 11)
                    beforegold = totalgold
                    totalgold = totalgold * (1 + (0.01 * gg)) + 100
                    gg = totalgold - beforegold + 100
                    print(f"You defeated the buffalo! you were paid {gg} gold and gained {gdxp} division experience.")
                    dxp += gdxp
            else:
                print("Bounty failed!! A new one will be available in 20 minutes.")
            bountyready = 0
            tslq = time.time()
        else:
            print("You left the bounty board. A new bounty will be available in 20 minutes!")
            bountyready = 0
            tslq = time.time()
def fight():
    global bounty
    global subdivision
    global bountymonsters
    global level
    global currenthp
    global maxmp
    global currentmp
    global currenthp
    global inventory
    global defense
    global attack
    global knownattacks
    global wonbounty
    global knowndefenses
    if bounty == 7:
        correct = 0
        print("You encountered THE QUIZMASTER!")
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("How much hp do you have right now?\n> ")
        updatestats()
        if str(inp) == str(currenthp):
            print("SUCCESS!")
            correct += 1
        else:
            print("FAILED.. You have " + str(currenthp) + " health right now.")
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("What is your subdivision?\n> ")
        inp = inp.upper()
        if str(inp) == str(subdivision):
            print("SUCCESS!")
            correct += 1
        else:
            print(f"FAILED.. Your subdivision is {subdivision}.")
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("1 or 2?\n> ")
        ca = randrange(1, 3)
        if inp == str(ca):
            print("SUCCESS!")
            correct += 1
        else:
            print(f"FAILED.. The answer was {ca}!")
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("What's up?\n> ")
        print("SUCCESS!")
        correct += 1
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("Name an attack you have!\n> ")
        if inp.upper() in knownattacks:
            print("SUCCESS!")
            correct += 1
        else:
            print(f"FAILED.. You could have answered the following: {knownattacks}!")
        if correct > randrange(2, 4):
            print("You win the quiz. Thanks for playing!")
            wonbounty = 1
            return
        else:
            print("You failed the quiz.. Thanks for playing!")
            wonbounty = 0
            return
    else:
        updatestats()
        global monsterhp
        global dlevel
        monsterhp = round(level * 10 * (dlevel + 1) * (maxhp * 0.01))
        global monsterdmg
        monsterdmg = round(monsterhp / 225) + 10
        global monster
        monster = bountymonsters[bounty]
        global charge
        charge = 0
        global monsteraction
        monsteraction = "odjvnso"
        global smoke
        smoke = 0
        global freeze
        freeze = 0
        currentmp = maxmp
        global burn
        global spikes
        spikes = 0
        burn = 0
        global combo
        global focused
        focused = False
        combo = 0
        global targeted
        targeted = 0
        global canreflect
        canreflect = 0
        global run
        global doused
        global shines
        shines = 0
        global railready
        railready = False
        global dlt
        dlt = False
        global shadowed
        shadowed = False
        doused = 0
        run = 0
        print("You encountered " + monster + "!")
        turn()
def turn():
    global dlt
    global focused
    global run
    global railready
    global monster
    global canreflect
    global targeted
    global monsterhp
    global burn
    global combo
    global freeze
    global currenthp
    global currentmp
    global maxmp
    global shines
    global smoke
    global monsteraction
    global spikes
    global monsterdmg
    global charge
    global bounty
    global done
    global subdivision
    global inputingmove
    global bountymonsters
    global level
    global shadowed
    global monsterdmg
    global currenthp
    global doused
    global maxmp
    global currentmp
    global currenthp
    global inventory
    global defense
    global attack
    global knownattacks
    global wonbounty
    global knowndefenses
    if run > 0:
        return
    if monsterhp < 1:
        wonbounty = 1
        return
    if currenthp < 1:
        wonbounty = 0
        return
    done = False
    print(f"-------{str(monster)} -------")
    print(str(monsterhp) + " health")
    print(str(monsterdmg) + " attack")
    print(f"------- YOU -------")
    print(str(currenthp) + " health")
    print(str(attack) + " attack")
    print("-------------------")
    if shadowed is True:
        print("Your SHADOW CLONE attacks!")
        print(f"Your SHADOW CLONE dealt {attack * randrange(2, 8)} damage to the enemy.")
        if randrange(1, 4) == 3:
            print("Your shadow clone faded away...")
            shadowed = False
    inp = None
    if maxmp > 0:
        if maxmp != currentmp:
            currentmp += 25
            print("You regained some mp.")
            if currentmp > maxmp:
                currentmp = maxmp
                print(str(currentmp) + " mp")
    if smoke == 1:
        print("The smoke cleared...")
        smoke = 0
    elif smoke == 2:
        smoke = 1
    elif smoke == 3:
        smoke = 2
    if burn > 0:
        print("The enemy was dealt " + str(round(monsterhp * 0.01)) + " damage from burn!")
        monsterhp -= monsterhp * 0.01
        burn -= 1
        if burn == 0:
            print("The burn wore off...")
    if targeted > 0:
        targeted -= 1
        if targeted == 0:
            print("Your accuracy boost wore off...")
    inputingmove = 1
    while inputingmove == 1:
        inp = input("What do you do?\nATTACK || DEFEND || ITEM || RUN\n> ")
        inp = inp.upper()
        if inp == "RUN":
            print("You ran!")
            print("You lost the bounty...")
            run = 1
            wonbounty = 0
            return
        elif inp == "ATTACK":
            inp = input("Pick an attack:\n" + str(knownattacks) + "\n> ").upper()
            if inp in knownattacks:
                print("You used " + inp + "!")
                inputingmove = 0
            else:
                print("That isn't an attack!")
                continue
        elif inp == "DEFEND":
            inp = input("Pick a defense:\n" + str(knowndefenses) + "\n> ").upper()
            if inp in knowndefenses:
                print("You used " + inp + "!")
                inputingmove = 0
            else:
                print("That isn't a defense!")
                continue
        elif inp in knowndefenses or inp in knownattacks:
            print("You used " + inp + "!")
            inputingmove = 0
        elif inp == "ITEM":
            inp = input(F"What item would you like to use?\n{str(inventory)}\n> ").upper()
            if inp in inventory:
                if inp == "BOMB":
                    print("You used " + inp + "!")
                    inputingmove = 0
                elif inp == "ROPE":
                    print("You used " + inp + "!")
                    inputingmove = 0
                elif inp == "LAMP OIL":
                    print("You used " + inp + "!")
                    inputingmove = 0
                else:
                    print("That isn't a useable item!!")
                    continue
            else:
                print("That isn't an item you have!")
                continue
        else:
            print("That isn't an option!")
            continue
    if 1 == 1:
        prevmonsteraction = monsteraction
        if run > 0:
            return
        if monsterhp < 1:
            wonbounty = 1
            return
        if currenthp < 1:
            wonbounty = 0
            return
        if freeze > 0:
            print("The enemy is frozen!")
            monsteraction = "frozen"
            freeze -= 1
            if freeze == 0:
                print("The enemy warmed up...")
        else:
            monsteraction = random.choice(["attacks", "blocks", "dodges"])
            print("The enemy " + str(monsteraction) + "!")
        if run > 0:
            return
        if monsterhp < 1:
            wonbounty = 1
            return
        if currenthp < 1:
            wonbounty = 0
            return
        if monsteraction == "blocks":
            try:
                r = randrange(1, 5)
                if inp in knownattacks:
                    if inp == "HEAL":
                        print("..but there was no attack to block")
                    elif inp == "CHARGE":
                        print("..but there was no attack to block")
                    elif inp == "SMOKE BOMB":
                        print("..but there was no attack to block")
                    elif inp == "SHADOW CLONE":
                        print("..but there was no attack to block")
                    elif inp == "SHARPEN":
                        print("..but there was no attack to block")
                    elif inp == "MARK":
                        print("..but there was no attack to block")
                    elif inp == "SUPERSTORM":
                        print("..but the SUPERSTORM is UNBLOCKABLE!")
                    elif inp == "LOCK ON":
                        print("..but there was no attack to block")
                    elif inp == "SURPRISE ATTACK":
                        print("...but the enemy saw no attack to block!")
                    elif inp == "RAILGUN":
                        if railready is False or charge < 1:
                            print("...but there was no attack to block!")
                    elif r == 1:
                        print("The enemy parried your " + str(inp) + "!")
                        print("You lost " + str(round(int(monsterdmg * 0.75))) + " health!")
                        currenthp -= round(monsterdmg * 0.75)
                        if currenthp < 0:
                            currenthp = 0
                        combo = 0
                        turn()
                    elif r == 2:
                        print("The enemy blocked your " + str(inp) + "!")
                        combo = 0
                        turn()
                    elif r == 3 or r == 4:
                        print("The block failed!")
                else:
                    print("..but there was no attack to block")
            except:
                print("..but there was no attack to block")
        if monsteraction == "dodges":
            try:
                if inp in knownattacks:
                    if inp == "HEAL":
                        print("..but there was no attack to dodge")
                    elif inp == "CHARGE":
                        print("..but there was no attack to dodge")
                    elif inp == "SMOKE BOMB":
                        print("..but there was no attack to dodge")
                    elif inp == "SHADOW CLONE":
                        print("..but there was no attack to dodge")
                    elif inp == "MARK":
                        print("..but there was no attack to dodge")
                    elif inp == "SUPERSTORM":
                        print("..but the SUPERSTORM can't be dodged!")
                    elif inp == "LOCK ON":
                        print("..but there was no attack to dodge")
                    elif inp == "SHARPEN":
                        print("..but there was no attack to dodge")
                    elif inp == "SURPRISE ATTACK":
                        print("...but the enemy saw no attack to dodge!")
                    elif inp == "RAILGUN":
                        if railready is False or charge < 1:
                            print("...but there was no attack to dodge!")
                    elif randrange(1, 3) == 1:
                        print("The enemy dodges your " + str(inp) + "!")
                        combo = 0
                        turn()
                    else:
                        print("The enemy dodged, but still got hit!")
                else:
                    print("..but there was no attack to dodge")
            except:
                print("..but there was no attack to dodge")
        if monsteraction == "attacks":
            if done is True:
                xd = 1
            elif inp == "MASTER GUARD":
                if randrange(1, 3) == 1:
                    print("You masterfully guard the enemy attack!!")
                    combo += 1
                else:
                    print("You try to masterfully guard, but can't block in time!")
            elif prevmonsteraction == "dodges":
                done = True
                print("The enemy pulled out of a dodge into a DODGE ATTACK")
                if subdivision == "NINJA" and randrange(1, 5) == 4:
                    print("Your INNATE: NINJA SENSE allowed you to dodge the attack!")
                elif smoke == 1:
                    if randrange(1, 4) == 3:
                        print("...but the enemy couldn't find you in the smoke!")
                    else:
                        if inp not in knowndefenses:
                            losthp = round(monsterdmg * randrange(1, 5))
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            losthp = round(monsterdmg * (1, 3))
                            print("You lost " + str(losthp) + " health! You couldn't fully block the dodge attack.")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                elif inp not in knowndefenses:
                    losthp = round(monsterdmg * (defense / 450))
                    print("You lost " + str(losthp) + " health!")
                    currenthp -= losthp
                    if currenthp < 0:
                        currenthp = 0
                else:
                    losthp = round(monsterdmg * (defense / 450) / 2)
                    print("You lost " + str(losthp) + " health! You couldn't fully block the dodge attack.")
                    currenthp -= losthp
                    if currenthp < 0:
                        currenthp = 0
            else:
                done = True
                if subdivision == "NINJA" and randrange(1, 5) == 4:
                    print("Your INNATE: NINJA SENSE allowed you to dodge the attack!")
                elif smoke > 0:
                    if randrange(1, 4) == 3:
                        print("...but the enemy couldn't find you in the smoke!")
                    elif inp in knowndefenses:
                        if inp == "BLOCK":
                            print("You BLOCK the enemy's attack!")
                            if randrange(1, 4) == 3:
                                print("The block failed!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print("Success!")
                                if canreflect == 1:
                                    print("Your shiny shield reflects the attack!")
                                    print("The shine went away..")
                                    print(f"You dealt {monsterdmg * 2} damage back!")
                                    monsterhp -= monsterdmg * 2
                                    canreflect = 0
                        if inp == "PRISM SHIELD":
                            print("You raise your PRISM SHIELD!")
                            if canreflect == 1:
                                print("Your prismatic shield reflects the attack!")
                                print("The shine went away..")
                                print(f"You dealt {round(monsterdmg * 3.25)} damage back!")
                                monsterhp -= round(monsterdmg * 3.25)
                                canreflect = 0
                            else:
                                print("Your shield wasn't shiny enough to be a PRISM SHIELD! You blocked as normal..")
                                if randrange(1, 4) == 3:
                                    print("The block failed!")
                                    losthp = round(monsterdmg)
                                    print("You lost " + str(losthp) + " health!")
                                    currenthp -= losthp
                                    if currenthp < 0:
                                        currenthp = 0
                                else:
                                    print("Success!")
                        elif inp == "CLASH":
                            print("You CLASH with the enemy's attack!")
                            if randrange(1, 3) == 2:
                                print("The clash failed!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print("Success!")
                        elif inp == "THORN BLOCK":
                            print("You THORN BLOCK the enemy's attack!")  # depends on defense + shine
                            if randrange(1, 4) == 3:
                                print("The block failed!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print(f"Success! You dealt {round(0.2 * attack)} damage with thorns!")
                                monsterhp -= round(0.2 * attack)
                                if canreflect == 1:
                                    print("Your shiny shield reflects the attack!")
                                    print("The shine went away..")
                                    print(f"You dealt {monsterdmg * 2} damage back!")
                                    monsterhp -= monsterdmg * 2
                                    canreflect = 0
                        elif inp == "COUNTER":
                            print("You COUNTER the enemy's attack!")
                            if randrange(1, 4) == 3:
                                print("The counter failed!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print(f"Success! You countered the attack and dealt {round(0.5 * attack)} damage!")
                                monsterhp -= round(0.2 * attack)
                        elif inp == "SHADOW CLASH":
                            print("You SHADOW CLASH with the enemy's attack!")
                            if smoke == 0:
                                print("...but the enemy easily saw it coming!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print(f"In a haze of smoke, the enemy swings wildly...")
                                sleep(2)
                                print("You SHADOW CLASH!")
                                if randrange(1, 8) == 7:
                                    print("The SHADOW CLASH failed!")
                                    print("You fade into the smoke...")
                                else:
                                    print(
                                        f"Success! You clashed with the attack and dealt {round(attack * 1.25)} damage!")
                                    monsterhp -= round(0.2 * attack)
                        elif inp == "POWER CLASH":
                            print("You POWER CLASH with the enemy's attack!")
                            if charge == 0:
                                print("...but you weren't charged up for the clash!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print(f"You POWER CLASH!")
                                if randrange(1, 7) == 6:
                                    print("The POWER CLASH failed!")
                                    losthp = round(monsterdmg)
                                    print("You lost " + str(losthp) + " health!")
                                    currenthp -= losthp
                                    if currenthp < 0:
                                        currenthp = 0
                                else:
                                    print(f"Success! You clashed with the attack and dealt {round(attack * 3)} damage!")
                                    monsterhp -= round(3 * attack)
                        else:
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                    else:
                        losthp = round(monsterdmg)
                        print("You lost " + str(losthp) + " health!")
                        currenthp -= losthp
                        if currenthp < 0:
                            currenthp = 0
                elif inp in knowndefenses:
                    if inp == "BLOCK":
                        print("You BLOCK the enemy's attack!")
                        if randrange(1, 4) == 3:
                            print("The block failed!")
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            print("Success!")
                            if canreflect == 1:
                                print("Your shiny shield reflects the attack!")
                                print("The shine went away..")
                                print(f"You dealt {monsterdmg * 2} damage back!")
                                monsterhp -= monsterdmg * 2
                                canreflect = 0
                    if inp == "PRISM SHIELD":
                        print("You raise your PRISM SHIELD!")
                        if canreflect == 1:
                            print("Your prismatic shield reflects the attack!")
                            print("The shine went away..")
                            print(f"You dealt {round(monsterdmg * 3.25)} damage back!")
                            monsterhp -= round(monsterdmg * 3.25)
                            canreflect = 0
                        else:
                            print("Your shield wasn't shiny enough to be a PRISM SHIELD! You blocked as normal..")
                            if randrange(1, 4) == 3:
                                print("The block failed!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0
                            else:
                                print("Success!")
                    elif inp == "CLASH":
                        print("You CLASH with the enemy's attack!")
                        if randrange(1, 3) == 2:
                            print("The clash failed!")
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            print("Success!")
                    elif inp == "THORN BLOCK":
                        print("You THORN BLOCK the enemy's attack!")
                        if randrange(1, 4) == 3:
                            print("The block failed!")
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            print(f"Success! You dealt {round(0.2 * attack)} damage with thorns!")
                            monsterhp -= round(0.2 * attack)
                            if canreflect == 1:
                                print("Your shiny shield reflects the attack!")
                                print("The shine went away..")
                                print(f"You dealt {monsterdmg * 2} damage back!")
                                monsterhp -= monsterdmg * 2
                                canreflect = 0
                    elif inp == "COUNTER":
                        print("You COUNTER the enemy's attack!")
                        if randrange(1, 4) == 3:
                            print("The counter failed!")
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            print(f"Success! You countered the attack and dealt {round(0.5 * attack)} damage!")
                            monsterhp -= round(0.2 * attack)
                    elif inp == "SHADOW CLASH":
                        print("You SHADOW CLASH with the enemy's attack!")  # depends on defense + shine
                        if smoke == 0:
                            print("...but the enemy easily saw it coming!")
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            print(f"In a haze of smoke, the enemy swings wildly...")
                            sleep(2)
                            print("You SHADOW CLASH!")
                            if randrange(1, 8) == 7:
                                print("The SHADOW CLASH failed!")
                                print("You fade into the smoke...")
                            else:
                                print(f"Success! You clashed with the attack and dealt {round(attack * 1.25)} damage!")
                                monsterhp -= round(0.2 * attack)
                    elif inp == "POWER CLASH":
                        print("You POWER CLASH with the enemy's attack!")
                        if charge == 0:
                            print("...but you weren't charged up for the clash!")
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                        else:
                            print(f"You POWER CLASH!")
                            if randrange(1, 7) == 6:
                                print("The POWER CLASH failed!")
                                losthp = round(monsterdmg)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                                if currenthp < 0:
                                    currenthp = 0

                            else:
                                print(f"Success! You clashed with the attack and dealt {round(attack * 3)} damage!")
                                monsterhp -= round(3 * attack)
                    else:
                            losthp = round(monsterdmg)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                            if currenthp < 0:
                                currenthp = 0
                else:
                    losthp = round(monsterdmg)
                    print("You lost " + str(losthp) + " health!")
                    currenthp -= losthp
                    if currenthp < 0:
                        currenthp = 0
        if run > 0:
            return
        if monsterhp < 1:
            wonbounty = 1
            return
        if currenthp < 1:
            wonbounty = 0
            return
        if inp in knownattacks:
            if inp == "SHIELD BASH":
                print("You SHIELD BASH!")
                print("You dealt " + str(attack) + " damage.")
                monsterhp -= attack
            elif inp == "SPIKED SHIELD BASH":
                print("You SHIELD BASH!")
                print("You dealt " + str(attack * 1.5) + " damage.")
                monsterhp -= attack * 1.5
            elif inp == "CHARGE":
                if charge == 1:
                    print("You can't charge further!")
                else:
                    print("You CHARGE!")
                    print("You are charged up for a powerful attack!")
                    charge = 1
            elif inp == "POWER SLICE":
                print("You POWER SLICE!")
                if charge == 1:
                    print("You dealt " + str(attack * 3) + " damage.")
                    monsterhp -= attack * 3
                    charge = 0
                else:
                    print("You POWER SLICE!")
                    print("...you weren't charged for this attack!")
            elif inp == "POWER SLASH":
                print("You POWER SLASH!")
                if charge == 1:
                    print("You dealt " + str(round(attack * 4.5)) + " damage.")
                    monsterhp -= round(attack * 4.5)
                    charge = 0
                else:
                    print("You POWER SLICE!")
                    print("...you weren't charged for this attack!")
            elif inp == "SLASH":
                print("You SLASH!")
                print("You dealt " + str(attack * 1.5) + " damage.")
                monsterhp -= attack * 1.5
            elif inp == "SLICE":
                print("You SLICE!")
                print("You dealt " + str(attack * 1) + " damage.")
                monsterhp -= attack * 1.5
            elif inp == "SMOKE BOMB":
                print("You throw a SMOKE BOMB!")
                print("The battlefield was filled with smoke...")
                smoke = 3
            elif inp == "SHADOW CLONE":
                if shadowed is True:
                    print("You create a SHADOW CLONE!")
                    print("Your old one faded away..")
                else:
                    print("You create a SHADOW CLONE!")
                    shadowed = True
            elif inp == "SURPRISE ATTACK":
                print("You make a SURPRISE ATTACK!")
                if smoke > 0:
                    sleep(4)
                    print("You are clouded in smoke...")
                    sleep(4)
                    print("The enemy didn't know what hit them.")
                    monsterhp -= attack * 2 * smoke
                    sleep(4)
                else:
                    print("...but the enemy blocked your move because you were easy to spot!")
            elif inp == "BOLT":
                if currentmp > 14:
                    print("You fire a BOLT for 15 mp!")
                    print("You dealt " + str(attack) + " damage.")
                    if subdivision == "WIZARD":
                        print(f"Your INNATE: FOCUS PRISM allowed you to deal {round(attack * 0.25)} extra damage!")
                        monsterhp -= round(attack * 0.25)
                    currentmp -= 15
                    monsterhp -= attack
                else:
                    print("You don't have enough mp...")
            elif inp == "FINALE PULSE":
                if currentmp > 99:
                    print("You charge a FINALE PULSE!!")
                    input("Spam as many characters as possible to charge the pulse!\n(Press enter to begin)")
                    pstart = time.time()
                    pmult = 0
                    while pstart + 10 > time.time():

                        pmult += len(input("> "))
                    print(f"You charged the FINALE pulse with {pmult} characters..")
                    sleep(1.5)
                    print(f"You dealt {round(attack * (pmult * 0.1))} damage.")
                    if subdivision == "WIZARD":
                        print(f"Your INNATE: FOCUS PRISM allowed you to deal {round(attack * (pmult * 0.1) * 0.05)} extra damage!")
                        monsterhp -= round(attack * (pmult * 0.2) * 0.05)
                    monsterhp -= round(attack * (pmult * 0.1))
                else:
                    print("You don't have enough mp...")
            elif inp == "EMBER":
                if currentmp > 49:
                    print("You fire an EMBER for 50 mp!")
                    print("The enemy was burned!")
                    if doused == 1:
                        print("The enemy was SET ABLAZE by the lamp oil!")
                        doused = 0
                        burndmg = round(randrange(5, 11) * attack * 1.2)
                        print(f"The enemy put itself out after losing {burndmg} health!")
                        monsterhp -= burndmg
                    else:
                        burn = 2
                        if subdivision == "WARLOCK":
                            print(f"Your INNATE: INFLICTOR allowed you to inflict more burn duration!")
                            burn += randrange(1, 3)
                else:
                    print("You don't have enough mp...")
            elif inp == "FROST":
                if currentmp > 49:
                    print("You summon a FROST for 50 mp!")
                    if randrange(1, 3) == 1:
                        print("The enemy was frozen!")
                        freeze = 1
                    else:
                        if subdivision == "WARLOCK":
                            if randrange(1, 3) == 1:
                                print(f"Your INNATE: INFLICTOR allowed you to freeze the enemy when it would have normally been unbothered!")
                                freeze = 1
                            else:
                                print("The enemy was unbothered by the cold.")
                        print("The enemy was unbothered by the cold.")
                else:
                    print("You don't have enough mp...")
            elif inp == "SUPERSTORM":
                if currentmp > 149:
                    print("You create a SUPERSTORM for 150 mp!")
                    print("The air crackles..")
                    print("You dealt " + str(attack * 4) + " damage.")
                    monsterhp -= attack * 4
                    print("The enemy was burned!")
                    if doused == 1:
                        print("The enemy was SET ABLAZE by the lamp oil!")
                        doused = 0
                        burndmg = round(randrange(5, 11) * attack * 1.2)
                        print(f"The enemy put itself out after losing {burndmg} health!")
                        monsterhp -= burndmg
                    else:
                        burn = 2
                        if subdivision == "WARLOCK":
                            print(f"Your INNATE: INFLICTOR allowed you to inflict more burn duration!")
                            burn += randrange(1, 3)
                    if randrange(1, 3) == 1:
                        print("The enemy was frozen!")
                        freeze = 1
                    else:
                        if subdivision == "WARLOCK":
                            if randrange(1, 3) == 1:
                                print(
                                    f"Your INNATE: INFLICTOR allowed you to freeze the enemy when it would have normally been unbothered!")
                                freeze = 1
                            else:
                                print("The enemy was unbothered by the cold.")
                        print("The enemy was unbothered by the cold.")
                    print("The battlefield was filled with smoke...")
                    smoke = 2

            elif inp == "BEAM":
                if currentmp > 59:
                    print("You fire a BEAM for 60 mp!")
                    print("You dealt " + str(attack * 1.6) + " damage.")
                    if subdivision == "WIZARD":
                        print(f"Your INNATE: FOCUS PRISM allowed you to deal {round(attack * 1.6 * 0.25)} extra damage!")
                        monsterhp -= round(attack * 1.6 * 0.25)
                    currentmp -= 60
                    monsterhp -= attack * 1.6
                else:
                    print("You don't have enough mp...")
            elif inp == "HEAL":
                if currentmp > 39:
                    print("You heal yourself for 40 mp!")
                    print("You healed " + str(maxhp * 0.25) + " damage.")
                    currentmp -= 40
                    currenthp += maxhp * 0.25
                    if subdivision == "CLERIC":
                        print(f"Your INNATE: MEDICINAL allowed you to gain {(maxhp * 0.25) * 0.5} extra health!")
                        currenthp += maxhp * 0.25 * 0.5
                    if currenthp > maxhp:
                        currenthp = maxhp
                else:
                    print("You don't have enough mp...")
            elif inp == "LIFEBEAM":
                if currentmp > 99:
                    print("You shot a LIFEBEAM for 100 mp!")
                    print(f"You stole {attack} life from the enemy!.")
                    currentmp -= 100
                    monsterhp -= attack
                    currenthp += attack
                    if currenthp > maxhp:
                        currenthp = maxhp
                else:
                    print("You don't have enough mp...")
            elif inp == "SHOT":
                print("You shoot a SHOT!")
                if targeted > 0:
                    if randrange(1, 7) == 6:
                        if subdivision == "SNIPER":
                            if randrange(1, 4) == 3:
                                print("Your INNATE: DEADEYE kept you from missing the shot!")
                                print("You dealt " + str(round(attack * 1.5)) + " damage.")
                                monsterhp -= round(attack * 1.5)
                            else:
                                print("MISS!")
                        else:
                            print("MISS!")
                    else:
                        print("HIT! You dealt " + str(round(attack * 1.5)) + " damage.")
                        monsterhp -= round(attack * 1.5)
                elif randrange(1, 5) == 4:
                    print("MISS!")
                else:
                    print("HIT! You dealt " + str(round(attack * 1.5)) + " damage.")
                    monsterhp -= round(attack * 1.5)
            elif inp == "SHARPSHOOT":
                print("You SHARPSHOOT!")
                if targeted > 0:
                    if randrange(1, 9) == 8:
                        if subdivision == "SNIPER":
                            if randrange(1, 4) == 3:
                                print("Your INNATE: DEADEYE kept you from missing the shot!")
                                print("You dealt " + str(round(attack * 2)) + " damage.")
                                monsterhp -= round(attack * 2)
                            else:
                                print("MISS!")
                        print("MISS!")
                    else:
                        print("HIT! You dealt " + str(attack * 2) + " damage.")
                        monsterhp -= attack * 2
                elif randrange(1, 7) == 6:
                    if subdivision == "SNIPER":
                        if randrange(1, 4) == 3:
                            print("Your INNATE: DEADEYE kept you from missing the shot!")
                            print("You dealt " + str(round(attack * 2)) + " damage.")
                            monsterhp -= round(attack * 2)
                        else:
                            print("MISS!")
                    print("MISS!")
                else:
                    print("HIT! You dealt " + str(attack * 2) + " damage.")
                    monsterhp -= attack * 2
            elif inp == "AMBUSH SNIPE":
                print("You AMBUSH SNIPE!")
                if dlt != True:
                    print("...the enemy was ready for the snipe! seems like you need to catch the enemy off guard.")
                elif targeted > 0:
                    if randrange(1, 17) == 8:
                        print("MISS!")
                    else:
                        print("With precise beauty, you launch a shot at the enemies' unguarded head.")
                        if randrange(1, 4) == 1:
                            print("HEADSHOT! You dealt " + str(attack * 7) + " damage.")
                            monsterhp -= attack * 7
                        else:
                            print(f"HIT! You dealt {attack * 5} damage.")
                            monsterhp -= attack * 5
                elif randrange(1, 14) == 6:
                    print("MISS!")
                else:
                    print("HIT! You dealt " + str(attack * 5) + " damage.")
                    monsterhp -= attack * 5
            elif inp == "MARK":
                print("You MARK the enemy. You are more accurate now!")
                targeted = 2
            elif inp == "LOCK ON":
                print("You LOCK ON to the enemy. You are more accurate now!")
                targeted = 3
            elif inp == "CHARGE SHOT":
                if charge == 1:
                    if targeted > 0:
                        if randrange(1, 8) == 7:
                            print("MISS!")
                            print("Your charge went away.")
                            charge = 0
                        else:
                            print("HIT! You dealt " + str(attack * 3) + " damage.")
                            monsterhp -= attack * 3
                    elif randrange(1, 6) == 5:
                        print("You missed your shot! Your charge went away..")
                        charge = 0
                    else:
                        print("You dealt " + str(attack * 3) + " damage! Your charge went away..")
                        monsterhp -= attack * 3
                        charge = 0
                else:
                    print("You CHARGE SHOT!")
                    print("...you weren't charged for this attack.")
            elif inp == "CHARGE SHARPSHOT":
                if charge == 1:
                    if targeted > 0:
                        if randrange(1, 10) == 9:
                            print("MISS!")
                            print("Your charge went away.")
                            charge = 0
                        else:
                            print("HIT! You dealt " + str(attack * 3) + " damage.")
                            monsterhp -= attack * 3
                    elif randrange(1, 8) == 7:
                        print("You dealt " + str(attack * 3) + " damage!")
                        monsterhp -= attack * 3
                        charge = 0
                    else:
                        print("You missed!")
                        print("Your charge went away..")
                        charge = 0
                else:
                    print("You CHARGE SHARPSHOT!")
                    print("...you weren't charged for this attack")
            elif inp == "BURST":
                print("You shoot a BURST!")
                hits = 0
                for i in 1, 2, 3:
                    if targeted > 0:
                        if randrange(1, 7) == 6:
                            print("MISS!")
                        else:
                            print("HIT!")
                            hits += 1
                    elif randrange(1, 5) == 4:
                        print("MISS!")
                    else:
                        print("HIT!")
                        hits += 1
                print("You hit " + str(hits) + " shots and dealt " + str(attack * hits) + " damage!")
                monsterhp -= attack * hits
            elif inp == "RAILGUN":
                if charge == 1:
                    if railready is True:
                        powerup = "⬜"
                        for i in 1, 2, 3, 4, 5, 6, 7:
                            print(powerup)
                            powerup = powerup + "⬜"
                            sleep(0.5)
                        sleep(1)
                        print("🟥🟥🟥🟥🟥🟥🟥")
                        print("WHAM! You dealt " + str(round(attack * 6)) + " damage.")
                        print("⬛⬛⬛⬛⬛⬛")
                        monsterhp -= round(attack * 6)
                        railready = False
                        charge = 0
                    else:
                        print("You siphon power into your bow.\n ⬜⬜⬜⬛⬛⬛\nThe railgun is halfway to ready.")
                        railready = True
                else:
                    print("You aren't charged up to use the RAILGUN!")
            elif inp == "TURBOBURST":
                print("At lightning speed, the shots spray..")
                hits = 0
                for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
                    sleep(1)
                    if targeted > 0:
                        if randrange(1, 6) == 5:
                            print("MISS!")
                        else:
                            print("HIT!")
                            hits += 1
                    elif randrange(1, 4) == 3:
                        print("MISS!")
                    else:
                        print("HIT!")
                        hits += 1
                print("You hit " + str(hits) + " shots and dealt " + str(attack * hits) + " damage!")
                monsterhp -= attack * hits
            elif inp == "PUNCH":
                print("You PUNCH!")
                print("You dealt " + str(round(attack * 0.75)) + " damage.")
                monsterhp -= round(attack * 0.75)
            elif inp == "SHINE":
                print("You SHINE!")
                canreflect = 1
                shines += 1
                print("Your shield became shiny.")
            elif inp == "SUN'S SURFACE":
                if shines > 3:
                    print("Your shield glows with a firey halo.")
                    sleep(0.5)
                    print("An intense ray of light blasts forth!")
                    monsterhp -= attack * shines * 3
                    print(f"You dealt {attack * shines * 3} damage.")
                else:
                    print("Your shield was not shiny enough to superheat.")
                    monsterhp -= shines * attack
                    print(f"You dealt {shines * attack} damage!")
            elif inp == "SHIELD COMBO":
                print("You SHIELD COMBO!")
                combo += 1
                print(str(combo) + "x COMBO!")
                print("You dealt " + str(attack * combo) + " damage.")
                monsterhp -= attack * combo
            elif inp == "MASTER GUARD":
                print("You MASTER GUARD!!")
                combo += 1
                print(str(combo) + "x COMBO!")
                print("You dealt " + str(round(attack * combo * 0.3)) + " damage.")
                monsterhp -= attack * combo * 0.3
                print("Your defense was raised!")
                defense = round(defense * 1.23)


            elif inp == "COMBO PUNCH":
                print("You COMBO PUNCH!")
                combo += 1
                print(str(combo) + "x COMBO!")
                print("You dealt " + str(attack * combo) + " damage.")
                monsterhp -= attack * combo
            elif inp == "FOCUS POWER":
                print("You focus your power...")
                attack = attack * 1.2
                print("Your attack increased!")
                focused = True
            elif inp == "CLEAVE":
                print("You try to CLEAVE!")
                if focused is True:
                    if charge == 1:
                        print("You swing down with the might of a thousand tons.")
                        sleep(0.5)
                        print(f"WHAM!! You dealt {attack * 10} damage!")
                        monsterhp -= attack * 12
                    else:
                        print("You need to be charged up to cleave!")
                else:
                    print("You need to be focused to cleave!")
                focused = True
            elif inp == "SHARPEN":
                print("You sharpen your shield's spikes...")
                attack = attack * 1.2
                print("Your attack increased!")
                spikes += 1
            elif inp == "SPIKE SPEW":
                print("You spew a flurry of spikes at the enemy..")
                if spikes > 0:
                    print("They slice through the enemy!")
                    monsterhp -= attack * spikes * 4
                else:
                    print("They aren't sharp enough to fully hit!")
                    monsterhp -= attack * 3
            elif inp == "FINISHER":
                print("You swing a finishing blow!!")
                if monsterhp < randrange(750, 1251):
                    print("INSTAKILL!!")
                    monsterhp = 0
                else:
                    print("The enemy had too much hp to kill!")
            elif inp == "GUILLOTINE":
                print("You swing down a GUILLOTINE!!")
                if monsterhp < randrange(1750, 2501):
                    print("INSTAKILL!!")
                    monsterhp = 0
                else:
                    print("The enemy had too much hp to kill!")
        elif inp in knowndefenses:
            if inp == "GUARDIAN SHIELD":
                if currentmp > 49:
                    print("You create a GUARDIAN SHIELD!")
                    defense = round(defense * 1.25)
                    print("Your defense increased!")
                else:
                    print("You try to create a guardian shield, you don't have enough mp to use that...")
            if inp == "GUARD":
                print("You GUARD!")
                defense += monsterdmg * 0.1
                print("Your defense was raised!")
            if inp == "SHINE":
                print("You SHINE your shield!!")
                canreflect = 1
                print("Your shield is shiny enough to reflect enemy attacks!")
        else:
            if monsteraction != "attacks":
                print(f"Your {inp} failed because the enemy didn't attack!")
        if inp in inventory:
            if inp == "BOMB":
                print("You throw a BOMB at the enemy!")
                print(f"BOOM!! You dealt {attack * 5} damage!")
                inventory.remove("BOMB")
                monsterhp -= attack * 5
            elif inp == "ROPE":
                print("You whip a ROPE at the enemy!")
                print(f"You dealt {attack * 0.5} damage!")
                monsterhp -= attack * 0.5
            elif inp == "LAMP OIL":
                print("You douse the enemy in LAMP OIL!")
                doused = 1
        if "COMBO" not in inp:
            combo = 0
        if monsterhp < 1:
            print("You win the bounty!")
            wonbounty = 1
            return
        inputingmove = 1
        turn()
def shop():
    try:
        inp = input(
        "Welcome to the Emporium!\n-----------\nSwords - A swordsman's best friend."
        "\nShields - The ideal weapon for a defender.\nBows - The archer's passion.\n"
        "Staffs - To channel a mage's power.\nArmor - A must-have for adventurers.\n"
        "Jewelry - Powerful buffs.\nUtility - Useful utility items.\n-----------\n"
        "Enter a category to see those items, BUY to buy an item, or QUIT to leave the shop.\n> ")
        inp = inp.upper()
        if inp == "SWORDS":
            inp = input(
            "Swords\n-----------\nBASIC SWORD == 500 gold\n   Just your everyday sword.\n"
            "BROAD SWORD == 25000 gold\n   A larger, more powerful sword.\nPAPER SWORD == 125000 gold\n"
            "   Sharp.\nGLASS SWORD == 1000000 gold\n   Not quite a glass cannon.\nGOLDEN SWORD == 10000000 gold"
            "\n   A sharp and gold sword.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
            shopans(inp)
        elif inp == "SHIELDS":
            inp = input(
            "Shields\n-----------\nBASIC SHIELD == 500 gold\n   Just your everyday shield.\nBANDED SHIELD == 25000 gold"
            "\n  A wooden sword banded with iron.\nSTEEL SHIELD == 125000 gold\n   A shield forged from hardened steel."
            "\nTITANIUM SHIELD == 1000000 gold\n   A shield forged from the strongest titanium.\n"
            "GOLDEN SHIELD == 10000000 gold\n A powerful gold shield.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
            shopans(inp)
        elif inp == "STAFFS":
            inp = input(
            "Staffs\n-----------\nBASIC STAFF == 500 gold\n   Just your everyday staff.\nOAK STAFF == 25000 gold\n"
            "   A staff crafted from fine oak.\nSPRUCE STAFF == 125000 gold\n   A staff crafted from fine spruce.\n"
            "EBONY STAFF == 1000000 gold\n   A staff crafted from fine ebony.\nGOLDEN STAFF == 10000000 gold\n   "
            "A mystical staff crafted from shiny gold.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
            shopans(inp)
        elif inp == "BOWS":
            inp = input(
            "Bows\n-----------\nBASIC BOW == 500 gold\n   Just your everyday bow.\nSLENDER BOW == 25000 gold\n   "
            "A thin bow with whistling shots.\nSTRONG BOW == 125000 gold\n   A bow with the power of a giant.\n"
            "ELDER BOW == 1000000 gold\n   The bow used by only the greatest archers.\nGOLDEN BOW == 10000000 gold\n   "
            "A elegant bow crafted from smooth gold.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
            shopans(inp)
        elif inp == "ARMOR":
            inp = input(
            "Armor\n-----------\nBASIC ARMOR == 500 gold\n   Just your everyday armor.\nLEATHER ARMOR == 25000 gold\n   "
            "A sturdy set of armor made of thick leather.\nCOPPER ARMOR == 125000 gold\n   "
            "A strong set of armor made from malleable copper.\nTITANIUM ARMOR == 1000000 gold\n   "
            "An impenetrable layer of the strongest titanium.\nGOLDEN ARMOR == 10000000 gold\n   "
            "A glistening set of gold armor.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
            shopans(inp)
        elif inp == "JEWELRY":
            inp = input(
            "Jewelry\n-----------\nPLAINS RING == 1000 gold\n   Gives a bonus while wearing in the PLAINS.\n"
            "MOUNTAIN RING == 35000 gold\n   Gives a bonus while wearing in the MOUNTAINS.\nCAVE RING == 200000 gold"
            "\n   Gives a bonus while wearing in the CAVES.\nGRAVEYARD RING == 200000 gold\n"
            "   Gives a bonus while wearing in the GRAVERYARD.\n"
            "KING'S RING == 500000 gold\n   Gives a bonus while wearing in the CASTLE.\n-----------\n"
            "   Gives a bonus while wearing in the CASTLE.\n"
            "BUY | MENU | [CATEGORY] | QUIT\n> ")
            shopans(inp)
        elif inp == "UTILITY":
            inp = input("Utility\n-----------\nLAMP OIL == 50 rubees\n   For dark areas"
                        "\nROPE == 100 rubees\n   surprisingly slimy."
                        "\nBOMB == 5 rubees\n   The enemies will be blown away!\nMYSTERY KEY == 500000 gold\n   "
                        "found this in a dumpster. who knows what it does\n-----------\n"
                        "BUY | MENU | [CATAGORY] | QUIT \n> ")
            shopans(inp)
        elif inp == "QUIT":
            lol = 1
        elif inp == "BUY":
            buy()
        elif inp in shopitems:
            print("...say BUY to buy something... (or MENU/CATAGORY/QUIT)")
            inp = input("> ")
            shopans(inp)
        else:
            print("That isn't an option!")
            inp = 'MENU'
            shopans(inp)
    except:
        print("An error occured. You've probably been flipping through shop windows too much!")
def shopans(inp):
  try:
    inp = inp.upper()
    if inp == "MENU":
        shop()
    elif inp == "QUIT":
        return
    elif inp == "SELL":
        sell()
    elif inp == "BUY":
        buy()
    elif inp == "CATEGORY" or inp == "CATAGORY" or inp == "[CATEGORY]":
        ans = input("You need to pick a category!\nSwords | Shields | Bows | Staffs | Armor | JEWELRY\n> ")
        shopans(ans)
    elif inp == "SWORDS":
        inp = input(
            "Swords\n-----------\nBASIC SWORD == 500 gold\n   Just your everyday sword.\n"
            "BROAD SWORD == 25000 gold\n   A larger, more powerful sword.\nPAPER SWORD == 125000 gold\n"
            "   Sharp.\nGLASS SWORD == 1000000 gold\n   Not quite a glass cannon.\nGOLDEN SWORD == 10000000 gold"
            "\n   A sharp and gold sword.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
        shopans(inp)
    elif inp == "SHIELDS":
        inp = input(
            "Shields\n-----------\nBASIC SHIELD == 500 gold\n   Just your everyday shield.\nBANDED SHIELD == 25000 gold"
            "\n  A wooden sword banded with iron.\nSTEEL SHIELD == 125000 gold\n   A shield forged from hardened steel."
            "\nTITANIUM SHIELD == 1000000 gold\n   A shield forged from the strongest titanium.\n"
            "GOLDEN SHIELD == 10000000 gold\n A powerful gold shield.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
        shopans(inp)
    elif inp == "STAFFS":
        inp = input(
            "Staffs\n-----------\nBASIC STAFF == 500 gold\n   Just your everyday staff.\nOAK STAFF == 25000 gold\n"
            "   A staff crafted from fine oak.\nSPRUCE STAFF == 125000 gold\n   A staff crafted from fine spruce.\n"
            "EBONY STAFF == 1000000 gold\n   A staff crafted from fine ebony.\nGOLDEN STAFF == 10000000 gold\n   "
            "A mystical staff crafted from shiny gold.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
        shopans(inp)
    elif inp == "BOWS":
        inp = input(
            "Bows\n-----------\nBASIC BOW == 500 gold\n   Just your everyday bow.\nSLENDER BOW == 25000 gold\n   "
            "A thin bow with whistling shots.\nSTRONG BOW == 125000 gold\n   A bow with the power of a giant.\n"
            "ELDER BOW == 1000000 gold\n   The bow used by only the greatest archers.\nGOLDEN BOW == 10000000 gold\n   "
            "A elegant bow crafted from smooth gold.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
        shopans(inp)
    elif inp == "ARMOR":
        inp = input(
            "Armor\n-----------\nBASIC ARMOR == 500 gold\n   Just your everyday armor.\nLEATHER ARMOR == 25000 gold\n   "
            "A sturdy set of armor made of thick leather.\nCOPPER ARMOR == 125000 gold\n   "
            "A strong set of armor made from malleable copper.\nTITANIUM ARMOR == 1000000 gold\n   "
            "An impenetrable layer of the strongest titanium.\nGOLDEN ARMOR == 10000000 gold\n   "
            "A glistening set of gold armor.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
        shopans(inp)
    elif inp == "JEWELRY":
        inp = input(
            "Jewelry\n-----------\nPLAINS RING == 1000 gold\n   Gives a bonus while wearing in the PLAINS.\n"
            "MOUNTAIN RING == 35000 gold\n   Gives a bonus while wearing in the MOUNTAINS.\nCAVE RING == 200000 gold"
            "\n   Gives a bonus while wearing in the CAVES.\nGRAVEYARD RING == 200000 gold\n"
            "   Gives a bonus while wearing in the GRAVERYARD."
            "KING's RING == 500000 gold\n"
            "   Gives a bonus while wearing in the CASTLE.\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT\n> ")
        shopans(inp)
    elif inp == "UTILITY":
        inp = input(
            "Utility\n-----------\nLAMP OIL == 50 rubees\n   For dark areas\nROPE == 100 rubees\n   suprisingly slimy."
            "\nBOMB == 5 rubees\n   The enemies will be blown away!\nMYSTERY KEY == 500000 gold\n   "
            "found this in a dumpster. who knows what it does\n-----------\n"
            "BUY | MENU | [CATEGORY] | QUIT \n> ")
        shopans(inp)
    else:
        print("That isn't an option!")
        shop()
  except:
      print("An error occured. You've probably been flipping through shop windows too much!")
def sell():
    global inventory
    global totalgold
    global totalrubees
    global shopitems
    global rubyitems
    print("What do you want to sell? (or QUIT)")
    sale = input("> ")
    sale = sale.upper()
    if sale in inventory:
        if sale in shopitems:
            price = ((shopitems[sale]) * 0.75)
            totalgold += price
            inventory.remove(sale)
            print("You sold your " + str(sale) + " for " + str(price) + " gold.")
        else:
            print("You can't sell items that cost rubees!")
    elif inp == "QUIT":
        print("You left the shop.")
    else:
        print("You don't have a " + sale + " to sell!")
def buy():
    global inventory
    global totalgold
    global totalrubees
    global mountainsunlocked
    global shopitems
    global rubyitems
    print("What do you want to buy? (or QUIT to leave the shop)")
    purchase = input("> ")
    purchase = purchase.upper()
    if purchase in shopitems:
        if purchase not in inventory:
            price = shopitems[purchase]
            if 1 == 1:
                if "RING" in str(purchase):
                    ringcheck = 0
                    if 'PLAINS RING' in inventory:
                        ringcheck += 1
                    if 'MOUNTAIN RING' in inventory:
                        ringcheck += 1
                    if 'CAVE RING' in inventory:
                        ringcheck += 1
                    if 'GRAVEYARD RING' in inventory:
                        ringcheck += 1
                    if "KING'S RING" in inventory:
                        ringcheck += 1
                    if ringcheck > 2:
                        print("You have can only wear 3 rings! Sell one with SELL to buy another!")
                if "ARMOR" in str(purchase):
                    if "ARMOR" in str(inventory):
                        print("You already have armor! Sell it with SELL!")
                        return
                elif "SWORD" in str(purchase):
                    if division == "SWORDSMAN":
                        if "SWORD" in str(inventory):
                            print("You already have a sword! Sell it with SELL!")
                            return
                    else:
                        print("Only swordsmen can wield swords!")
                        return
                elif "SHIELD" in str(purchase):
                    if division == "DEFENDER":
                        if "SHIELD" in str(inventory):
                            print("You already have a shield! Sell it with SELL!")
                            return
                    else:
                        print("Only defenders can wield shields! For more defense, buy armor.")
                        return
                elif "BOW" in str(purchase):
                    if division == "ARCHER":
                        if "BOW" in str(inventory):
                            print("You already have a bow! Sell it with SELL!")
                            return
                    else:
                        print("Only archers can wield bows!")
                        return
                elif "STAFF" in str(purchase):
                    if division == "MAGE":
                        if "STAFF" in str(inventory):
                            print("You already have a staff! Sell it with SELL!")
                            return
                    else:
                        print("Only mages can wield staffs!")
                        return
                elif "ARMOR" in str(purchase):
                    if "ARMOR" in str(inventory):
                        print("You already have armor! Sell it with SELL!")
                        return
                if price <= totalgold:
                    totalgold = totalgold - price
                    inventory += [purchase]
                    print("you bought a " + str(purchase) + " for " + str(price) + " gold.")
                    if "GOLDEN" in purchase and purchase != "GOLDEN ARMOR":
                        print("You have unlocked 'ENHANCE'ing!")
                else:
                    print("you need more gold! (" + str(totalgold) + "/" + str(price) + " gold)")
                    buy()
        else:
            print("you already have a " + str(purchase) + "!")
            buy()
    elif purchase in rubyitems:
        price = (rubyitems[purchase])
        if price <= totalrubees:
            if purchase not in inventory:
                inventory += [purchase]
                totalrubees = totalrubees - price
                print("you bought a " + str(purchase) + " for " + str(price) +
                      " rubees.")
                if purchase == 'BOMB':
                    print("\nlaunch your bomb with 'BOOM'!")
                    if mountainsunlocked == 0:
                        print(
                            "You look around, and notice some mountains blocked by a boulder! Go to the mountains with 'MOVE [AREA]'")
            else:
                print("you already have that item!")
                buy()
        else:
            print("you need more rubees to buy that!")
            buy()
    elif purchase == 'QUIT':
        print("you left the shop.")
    elif purchase == 'LEAVE':
        print("you left the shop.")
    elif purchase == 'SHOP':
        shop()
    else:
        print("you cant buy that! see what you can buy in SHOP")
        buy()
def hunt():
    global level
    global totalxp
    global totalgold
    global totalrubees
    global plainsmonsters
    global mountainmonsters
    global cavemonsters
    global graveyardmonsters
    global castlemonsters
    global souls
    global area
    global weapon
    global lsc
    global currenthp
    global maxhp
    global tslh
    global defense
    global armor
    updatestats()
    gainedxp = int(randrange(5, 11)) * level
    gainedgold = int(randrange(1, 70))
    extra = ''
    strength = defense + attack
    monsters = plainsmonsters
    if area == 'PLAINS':
        monsters = plainsmonsters
        currenthp = (currenthp - (randrange(100, 201) - strength))
        if 'PLAINS RING' in inventory:
            extra = "\nYour PLAINS RING gave you an extra 35 gold!"
            totalgold += 35
    if area == 'MOUNTAINS':
        gainedgold = round(gainedgold * 5)
        gainedxp = round(gainedxp * 5)
        monsters = mountainmonsters
        currenthp = (currenthp - (randrange(300, 601) - strength))
        if 'MOUNTAIN RING' in inventory:
            if 1 == randrange(1, 5):
                extra = "\nYour MOUNTAIN RING gave you a bonus ruby!"
                totalrubees += 1
    if area == 'CAVES':
        gainedgold = gainedgold * 25
        gainedxp = gainedxp * 25
        currenthp = (currenthp - (randrange(600, 1201) - strength))
        monsters = cavemonsters
        if 'CAVE RING' in inventory:
            if lsc == 10:
                extra = "Your CAVE RING lights the way.. You found another enemy!"
                currenthp = maxhp
                lsc = 0
                hunt()
        else:
            lsc += 1
    if area == 'GRAVEYARD':
        gainedgold = gainedgold * 125
        gainedxp = gainedxp * 125
        currenthp = (currenthp - (randrange(1200, 2401) - strength))
        monsters = graveyardmonsters
        if 'GRAVEYARD RING' in inventory:
            if souls < 25:
                extra = "Your GRAVEYARD RING sucks in the soul of the enemy."
                souls += 1
            if currenthp < 1:
                if souls > 9:
                    print(
                        "You almost died fighting, but your GRAVEYARD RING used it's built up power to save you!"
                        " You didn't lose anything.")
                    souls -= 10
                    return
    if area == 'CASTLE':
        gainedgold = round(gainedgold * 250)
        gainedxp = round(gainedxp * 250)
        monsters = castlemonsters
        currenthp = (currenthp - (randrange(2500, 5556) - strength))
        if "KING'S RING" in inventory:
            if 1 == randrange(1, 3):
                gain = randrange(round(weapon * totalgold * 0.01), round(weapon * totalgold * 0.05))
                gainr = randrange(round(armor * totalrubees * 0.01), round(armor * totalrubees * 0.05))
                extra = f"\nYour KING'S RING showers you in riches!\nYou pocketed {gain} gold and {gainr} rubees!"
                totalgold += gain
                totalrubees += gainr
    if currenthp < 1:
        lostgold = round(int(totalgold * 0.1))
        print("You encountered " + str(
            random.choice(monsters.split(','))) + ", but you didn't survive the fight! You lost " + str(
            lostgold) + " gold..")
        totalgold -= round(int(totalgold * 0.1))
        currenthp = 0
        return
    if currenthp > maxhp:
        currenthp = maxhp
    totalgold = gainedgold + totalgold
    totalxp = totalxp + gainedxp
    print("You encountered " + random.choice(monsters.split(',')) + " in the " + area +
          "! \nYou got " + str(gainedxp) + " xp (" + str(totalxp) +
          " total) and " + str(gainedgold) + " gold (" + str(totalgold) +
          " total)\nYou have " + str(currenthp) + "/" + str(maxhp) + " hp." + extra)
    neededxp = 50 * 2 ** (level - 1)
    if totalxp >= neededxp:
        level = level + 1
        print('you LEVELED UP to ' + str(level) + '. Your attack, defense, and hp increased!')
        if division == "MAGE":
            print("Your mp also increased!")
    if 1 == randrange(1, 6):
        totalrubees = totalrubees + 1
        print('you also got a ruby')
def bomb():
    if 'BOMB' in inventory:
        global level
        global totalxp
        global totalgold
        global totalrubees
        global plainsmonsters
        global mountainmonsters
        global cavemonsters
        global graveyardmonsters
        global area
        global dungdone
        monsters = plainsmonsters
        gainedxp = int(randrange(5, 11)) * level * 50
        gainedgold = int(randrange(1, 70)) * 50
        if area == 'MOUNTAINS':
            gainedgold = gainedgold * 5
            gainedxp = gainedxp * 5
            monsters = mountainmonsters
        if area == 'CAVES':
            gainedgold = gainedgold * 25
            gainedxp = gainedxp * 25
            monsters = cavemonsters
        if area == 'GRAVEYARD':
            gainedgold = gainedgold * 125
            gainedxp = gainedxp * 125
            monsters = cavemonsters
        if area == 'CASTLE':
            gainedgold = gainedgold * 250
            gainedxp = gainedxp * 250
            monsters = mountainmonsters
        totalgold = gainedgold + totalgold
        totalxp = totalxp + gainedxp
        inventory.remove('BOMB')
        print("You found an encampment of 50 monsters in the " + area + "!! \nYou got " + str(gainedxp) + " xp (" + str(
            totalxp) + " total) and " + str(gainedgold) + " gold (" + str(totalgold) + " total)")
        print("-----------")
        neededxp = 50 * 2 * (level - 1)
        if totalxp >= neededxp:
            level = level + 1
            print('you LEVELED UP to ' + str(level) + '. Your attack, defense, and hp increased!')
            if division == "MAGE":
                print("Your mp also increased!")
            print("any rubees got destroyed by the bomb.")
    else:
        print("you don't have a bomb to ignite")
def cmd():
    global dragonbeaten
    global inventory
    global totalgold
    global totalrubees
    global level
    global totalxp
    global checkinv
    global area
    global mountainsunlocked
    global cavesunlocked
    global graveyardunlocked
    global castleunlocked
    global maxhp
    global attack
    global defense
    global currenthp
    global subdivision
    global knownattacks
    global knowndefenses
    global dxp
    global dlevel
    global gem
    updatestats()
    print("-----------\nWhat would you like to do?")
    inp = input("> ")
    inp = inp.upper().split()
    try:
        if inp[0] == "MOVE":
            if inp[1] != "PLAINS":
                if inp[1] != "MOUNTAINS":
                    if inp[1] != "CAVES":
                        if inp[1] != "GRAVEYARD":
                            if inp[1] != "CASTLE":
                                print("You can't go there!\nPlaces to go: PLAINS, MOUNTAINS, CAVES, GRAVEYARD, CASTLE")
    except:
        try:
            if inp[0] == "MOVE":
                print("The correct format is MOVE [PLACE]\nPlaces to go: PLAINS, MOUNTAINS, CAVES, GRAVEYARD, CASTLE")
                return
            else:
                print("There was problem processing your input, make sure to format correctly.")
                return
        except:
            print('that isnt a command!\n stuck? try "HELPME" ')
            return
    if inp[0] == 'HUNT':
        hunt()
    if inp[0] == 'ENHANCE':
        jshop()
    elif inp[0] == 'HELPME' or inp[0] == 'HELP':
        txt = "-----------\n- COMMANDS -\nGUIDE - A starter guide!\n" \
              "SAVE - Save your game!\nHUNT - Get loot!\nBOUNTY - Strategic combat for big rewards!\n" \
              "SHOP - Buy weapons, gear, and accessories!\nBUY - Buy items!\nME - See your stats and inventory!\n" \
              "MOVE - Move to a better area!\nUPDATENOTES - See the latest update's notes!"
        if 'BOMB' in inventory:
            txt += "\nBOOM - Launch a bomb at a group of enemies!"
        if "GOLDEN SWORD" in inventory or "GOLDEN SHIELD" in inventory\
                or "GOLDEN STAFF" in inventory or "GOLDEN BOW" in inventory:
            txt += "\nENHANCE - Enhance a golden weapon!"
        print(txt)
    elif inp[0] == 'SHOP':
        shop()
    elif inp[0] == 'UPDATENOTES':
        print("bv1.6.2 UPDATE NOTES:\n\
        - added 'ENHANCE'ment for gold weapons\n\
        - fixed a bug where health could go negative\n\
        - fixed many bounty related bugs")
    elif inp[0] == 'BUY':
        buy()
    elif inp[0] == 'SELL':
        sell()
    elif inp[0] == 'GUIDE' or inp[0] == " GUIDE":
        print("Slayer is a text-based roguelike. You play the game by typing in commands!")
        sleep(4)
        hc = True
        while hc is True:
            inp = input("Try putting in 'hunt'.\n> ")
            if inp.upper() == 'HUNT':
                hunt()
                hc = False
            else:
                print("That isn't HUNT! Put in 'hunt' plainly, then hit enter.")
        sleep(3)
        print("Good job! You hunted. Hunts give resources like gold and experience,"
              " and even rubees if you're lucky! Gold and rubees are used in the SHOP. Take a look!")
        sleep(3)
        sc = True
        while sc is True:
            inp = input("Try putting in 'shop'.\n> ")
            if inp.upper() == 'SHOP':
                shop()
                sc = False
            else:
                print("That isn't SHOP! Put in 'shop' plainly, then hit enter.")
        print("That's all there is to it for now! Well, besides BOUNTIES.\n"
              "However, you will probably want better gear to start one. If you ever need help, put GUIDE or HELPME!\n"
              "Time to get grinding!")
    elif inp[0] == 'BOUNTY':
        startbounty()
    elif inp[0] == 'MOVE':
        if inp[1] == 'PLAINS':
            if area != 'PLAINS':
                area = 'PLAINS'
                print("You moved to the plains!")
            else:
                print("You are already in the plains!")
        elif inp[1] == 'MOUNTAINS':
            if mountainsunlocked == 1:
                if area != 'MOUNTAINS':
                    area = 'MOUNTAINS'
                    print("You have moved to the mountains.")
                else:
                    print("You are already in the mountains!")
            else:
                print("A boulder is blocking your path.. Seems like you need something to remove it.")
                if "BOMB" in inventory:
                    inp = input("Would you like to throw a bomb at it? (YES/NO)\n> ")
                    inp = inp.upper()
                    if inp == "YES" or inp == "BOOM":
                        print("BOOM!!!")
                        inventory.remove('BOMB')
                        mountainsunlocked = 1
                        area = 'MOUNTAINS'
                        print("You have moved to the mountains. (The monsters here give better rewards!)")
                        print("You can now go to the caves.")
                    else:
                        print("You decided not to throw the bomb.")
        elif inp[1] == 'CAVES':
            if cavesunlocked == 1:
                if area != 'CAVES':
                    area = 'CAVES'
                    print("You have moved to the caves.")
                else:
                    print("You are already in the caves!")
            else:
                if mountainsunlocked == 1:
                    print(
                        "You try to move into the caves..\nThe passage is too dark! There seem to be unlit lamps, but they have no fuel.")
                    if "LAMP OIL" in inventory:
                        inp = input("Would you like to use your lamp oil? (YES/NO)\n> ")
                        inp = inp.upper()
                        if inp == "YES":
                            print("You oil and light the lamps.")
                            inventory.remove('LAMP OIL')
                            cavesunlocked = 1
                            area = 'CAVES'
                            print(
                                "You have moved to the caves. (The monsters here give much better rewards!\nYou can now go to the graveyard.")
                        else:
                            print("You decided not to use the lamp oil.")
                else:
                    print("You need to get to the mountains first to get to the caves!")
        elif inp[1] == 'GRAVEYARD':
            if graveyardunlocked == 1:
                if area != 'GRAVEYARD':
                    area = 'GRAVEYARD'
                    print("You have moved to the graveyard.")
                else:
                    print("You are already in the graveyard!")
            else:
                if cavesunlocked == 1:
                    print("You try to exit the caves..\nThe way up is too steep! You will need something to scale it with.")
                    if "ROPE" in inventory:
                        inp = input("Would you like to use your rope? (YES/NO)\n> ")
                        inp = inp.upper()
                        if inp == "YES":
                            print("You scale the slope with your rope.")
                            inventory.remove('ROPE')
                            graveyardunlocked = 1
                            area = 'GRAVEYARD'
                            print("You have moved to the graveyard. (The monsters here give way better rewards!")
                        else:
                            print("You decided not to use your rope.")
                else:
                    print("You need to get to the caves first to get to the graveyard!")
        elif inp[1] == 'CASTLE':
            if castleunlocked == 1:
                if area != 'CASTLE':
                    area = 'CASTLE'
                    print("You have entered the CASTLE.")
                else:
                    print("You are already in the CASTLE!")
            else:
                if cavesunlocked != 1:
                    print("You need to get to the caves first to get to the castle!")
                else:
                    print("The gate is locked.... Seems like you need something to unlock it.")
                    if "MYSTERY KEY" in inventory:
                        print("You unlocked the door with your MYSTERY KEY.")
                        print("ka-chink!")
                        castleunlocked = 1
                        area = 'CASTLE'
                        print("You have entered the castle. (The monsters here give very good rewards!)")
                        print("You can now enter the DUNGEON..")
    elif inp[0] == 'DUNGEON':
        print("dungeons have been removed for a HUGE REVAMP coming soon!")
    elif inp[0] == 'BOOM':
        bomb()
    elif inp[0] == 'DEVTOOLS':
            level = int(input("level: "))
            totalxp = int(input("totalxp: "))
            totalgold = int(input("totalgold: "))
            totalrubees = int(input("totalrubees: "))
            dxp = int(input("dxp: "))
            area = str(input("area: "))
    elif inp[0] == 'ME':
        updatestats()
        if inventory == checkinv:
            pinv = "You have nothing in your inventory!"
        else:
            pinv = "Your inventory:\n" + str(inventory)
        if gem == "None" and "GOLDEN SWORD" in inventory or gem == "None" and "GOLDEN SHIELD" in inventory\
                or gem == "None" and "GOLDEN STAFF" in inventory or gem == "None" and "GOLDEN BOW" in inventory:
            pgem = "Your weapon has no enhancement! (See 'ENHANCE')"
        elif gem != "None":
            pgem = f"Your weapon is enhanced with a {gem}."
        else:
            pgem = ""
        print(f"{subdivision}: Division level {dlevel}, {dxp} division xp")
        print("Attacks: " + str(knownattacks))
        print("Defenses: " + str(knowndefenses))
        print("Level: " + str(level))
        print("Hp: " + str(currenthp) + "/" + str(maxhp))
        print("Attack: " + str(attack))
        print("Defense: " + str(defense))
        print("Area: " + str(area))
        print("Gold: " + str(totalgold))
        print("Rubees: " + str(totalrubees))
        print(pinv)
        print(pgem)
    elif inp[0] == "SAVE":
        save()
    else:
        print('that isnt a command! (try "HELPME") ')
while 1 == 1:
    cmd()

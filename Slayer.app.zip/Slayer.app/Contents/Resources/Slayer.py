# "slayer" and all applicable data and software is intellectual property of IceFire03#0300 (850446900209516594) and guarded under Discord and Replit ToS. You may not copy, modify, create derivative works based upon, distribute, sell, lease, or sublicense any property enclosed in this message. These actions are legally applicable to infringing on the intellectual property rights of IceFire03#0300 (850446900209516594) and may cause your account to be suspended or terminated, and/or legal action.
# -------------------------------
# DONT LOOK AT THE CODE IF YOU DONT WANT SPOILERS
from time import sleep
import os
import tkinter as Tk
window = Tk.Tk()
window.config(bg="black")
window.geometry('750x150')
window.title("How to start Slayer")
if os.name == "posix":
    Tk.Label(window,
             text="CLOSE THIS WINDOW IF YOU HAVE FOLLOWED THE BELOW STEPS TO START THE GAME\nIf you are not on MacOs, your way to access terminal may differ.\nTo begin the game:\nOpen terminal\n(command + space, and enter in terminal)\ncopy and paste in the below and hit enter!\n(triple click, cmd + c, click the terminal window, cmd + v)",
             fg="white", bg="black").pack()
else:
    Tk.Label(window,
             text="CLOSE THIS WINDOW IF YOU HAVE FOLLOWED THE BELOW STEPS TO START THE GAME\nIf you are not on Windows, your way to access terminal may differ.\nTo begin the game in Windows:\nOpen a command-line\n(windows key + x, select command prompt)\ncopy and paste in the below and hit enter!\n(triple click, ctrl + c, click the terminal window, ctrl + v)",
             fg="white", bg="black").pack()
ent = Tk.Entry(window, state='readonly', readonlybackground='black', fg='white')
var = Tk.StringVar()
var.set("python3 " + os.path.abspath(__file__))
ent.config(textvariable=var, relief='flat')
ent.pack()
window.lift()
print('Close the "How to start Slayer" window to begin the game in this window!')
window.mainloop()
sdl = os.path.abspath(__file__)
sdl = sdl[0:int(len(sdl) - 9)]
sdl = str(sdl) + "savedata.txt"
from time import sleep
import random
from random import randrange
import time

dragonbeaten = 0
willpower = 0
dmg = 0
dungdone = 0
souls = 0
bountyready = 0
inventory = []
checkinv = []
knownattacks = []
knowndefenses = []
shopitems = {'BASIC SWORD': 500, 'BROAD SWORD': 25000, 'PAPER SWORD': 125000, 'GLASS SWORD': 1000000,
             'GOLDEN SWORD': 10000000, 'BASIC SHIELD': 500, 'BANDED SHIELD': 25000, 'STEEL SHIELD': 125000,
             'TITANIUM SHIELD': 1000000, 'GOLDEN SHIELD': 10000000, 'BASIC BOW': 500, 'SLENDER BOW': 25000,
             'STRONG BOW': 125000, 'ELDER BOW': 1000000, 'GOLDEN BOW': 10000000, 'BASIC STAFF': 500, 'OAK STAFF': 25000,
             'SPRUCE STAFF': 125000, 'EBONY STAFF': 1000000, 'GOLDEN STAFF': 10000000, 'PLAINS RING': 1000,
             'MOUNTAIN RING': 35000, 'CAVE RING': 200000, 'MYSTERY KEY': 500000, 'BASIC ARMOR': 500,
             'LEATHER ARMOR': 25000, 'COPPER ARMOR': 125000, 'TITANIUM ARMOR': 1000000, 'GOLDEN ARMOR': 10000000}
rubyitems = {'LAMP OIL': 100, 'ROPE': 200, 'BOMB': 5}
level = int(1)
totalxp = int(1)
totalgold = int(1)
totalrubees = int(0)
area = "PLAINS"
mountainsunlocked = 0
cavesunlocked = 0
graveyardunlocked = 0
lsc = 10
tslh = time.time()
tslq = 1200
bountydescriptions = {1: "Kill a goliath", 2: "Reclaim stolen treasure", 3: "Get potion parts",
                      4: "Trolls attacking caravans", 5: "Young dragon terrorizing mountain village",
                      6: "Fruit gatherer needed", 7: "Take a quiz", 8: "Chest verifier needed", 9: "Food shortage"}
bountydefinitions = {
    1: "A goliath has been spotted in the mountains! It is en route to attack the village.. Please kill it for me!\n>> You camp out by the village, and hear the goliath approaching..",
    2: "A huge swarm of goblins stole my treasure! Please get it for me!\n>> You go to the location marked on the bounty..",
    3: "I need you to hunt down a slime boss for potion parts!\n>> You search for a boss slime..",
    4: "A group of trolls is repeatedly attacking supply shipments. Please take them down!\n>> You follow and guard the caravans..",
    5: "Please vanquish the dragon!\n>> You go to the location marked on the map..",
    6: "Please gather fruit from a dangerous area!\n>> You go to the area marked on the bounty..",
    7: "Take a quick quiz and you will be rewarded!\n>> You go to the area marked on the bounty..",
    8: "Please help me test these chests for mimics!\n>> You go to the bounty area and check the chests..",
    9: "The village is starving! Please kill a buffalo for food."}
bountymonsters = {1: "the GOLIATH", 2: "the GOBLIN HORDE", 3: "a SLIME BOSS", 4: "the TROLL RAIDERS",
                  5: "a DRAGON CHILD", 6: "a FRUITARIANIST WEREWOLF", 7: "nothing lol", 8: "a MIMIC", 9: "a BUFFALO"}
choosingdivision = 0
plainsmonsters = "a boar, a hyena,a jackal,a slime,an ogre,a swarm of bees,a troll,an evil cat,a zombie,a wearwolf,a wherewolf,a werewolf,a we'rewolf,a skeleton"
mountainmonsters = "bigfoot,an orc,a mountain dragon,a snow leopard,an adamantine golem, an arctic dwarf,an ice troll,an ice bat,a giant lizard,a cloud elemental"
cavemonsters = "a bat swarm,a vampire bat,a giant beetle,a cave troll,a one eyed troll,a scurrybug,a rock goblin,a recluse, a drow,a darkmantle,a crystal cryptid,a moss cryptid, a dark cryptid"
graveyardmonsters = "an undead,and infernal,a ghost,a necromancer,a flame spirit,a grim reaper,a wyrm,a spider queen,an arachnid amalgamation"
sleep(0.1)
print("Welcome to slayer!\n[V1.6.0 (beta)]\n----\nPlease wait for bootup......")


def load():
    global totalgold
    global totalrubees
    global level
    global totalxp
    global dxp
    global mountainsunlocked
    global cavesunlocked
    global graveyardunlocked
    loadline = input("What is the save slot number of your save file? (Or say CC for a cross-version transfer.)\n> ").upper()
    if loadline == "CC":
        inp = input("Load your save on a previous version and say CC during SAVE to get a file directory.\n Copy and paste that into here!\n> ")
        with open(inp, 'r') as file:
            savedata = file.readlines()
        with open(sdl, 'w') as file:
            file.writelines(savedata)
            print("Saves transferred.")
            return
    else:
        try:
            with open(sdl, 'r') as file:
                loadcode = file.readlines()[int(loadline)]
        except:
            sleep(0.1)
            print("That isn't a save slot!")
            return
        if loadcode == '\n':
             sleep(0.1)
             print("That save slot has no data!")
             return
    totalgold = int(loadcode[0:10])
    totalrubees = int(loadcode[10:17])
    level = int(loadcode[17:22])
    totalxp = int(loadcode[22:30])
    dxp = int(loadcode[39:46])
    mountainsunlocked = int(loadcode[46])
    cavesunlocked = int(loadcode[47])
    graveyardunlocked = int(loadcode[48])
    sleep(0.1)
    print("Save data loaded!\nNow, choose your class.")


def save():
    global mountainsunlocked
    global cavesunlocked
    global graveyardunlocked
    global level
    global totalxp
    global totalgold
    global totalrubees
    global dlevel
    global dxp
    global basehp
    global maxhp
    global baseatk
    global basedef
    global area
    save = ""
    sleep(0.1)
    print("INVENTORY IS NOT SAVED. Make sure to sell items before saving!")
    if totalgold < 9999999999:
        savegold = totalgold
    else:
        savegold = 999999999
    x = 10 - len(str(totalgold))
    for i in range(x):
        savegold = str(0) + str(savegold)
    save += savegold
    if totalrubees < 9999999:
        saverubees = totalrubees
    else:
        saverubees = 999999999
    x = 7 - len(str(totalrubees))
    for i in range(x):
        saverubees = str(0) + str(saverubees)
    save += saverubees
    if level < 99999:
        savelevel = level
    else:
        savelevel = 99999
    x = 5 - len(str(level))
    for i in range(x):
        savelevel = str(0) + str(savelevel)
    save += savelevel
    if totalxp < 99999999:
        savexp = totalxp
    else:
        savexp = 99999999
    x = 8 - len(str(savexp))
    for i in range(x):
        savexp = str(0) + str(savexp)
    save += savexp
    save += str(basehp)
    if len(str(baseatk)) == 2:
        saveatk = str(0) + str(baseatk)
    else:
        saveatk = baseatk
    save += str(saveatk)
    if len(str(basedef)) == 2:
        savedef = str(0) + str(basedef)
    else:
        savedef = str(basedef)
    save += savedef
    if dxp < 9999999:
        savedxp = dxp
    else:
        savedxp = 9999999
    x = 7 - len(str(savedxp))
    for i in range(x):
        savedxp = str(0) + str(savedxp)
    save += savedxp
    save += str(mountainsunlocked)
    save += str(cavesunlocked)
    save += str(graveyardunlocked)
    save += str(0)
    saveline = input("Type in a numerical line for your save file (max 10), or DELETE to delete a save.\nType CC to save data to a newer game version.\n> ")
    if saveline.upper() == "DELETE":
        sleep(0.1)
        print("Save slots:")
        lookup = '0'
        with open(sdl) as myFile:
            for num, line in enumerate(myFile, 1):
                if lookup in line:
                    sleep(0.1)
                    print(num)
        dkey = input("What save slot should be deleted?\n> ")
        try:
            with open(sdl, 'r') as file:
                savedata = file.readlines()
                savedata[int(dkey)] = ""
            with open(sdl, 'w') as file:
                file.writelines(savedata)
                sleep(0.1)
                print("Save deleted.")
                return
        except:
            sleep(0.1)
            print("Failed, make sure to input the correct line!")
            return
    elif saveline.upper() == "CC":
        sleep(0.1)
        print("To transfer saves, open the game on the newer version, enter CC, and paste in the below:\n" + sdl)
        return
    elif int(saveline) > 11:
        sleep(0.1)
        print("You can only have up to 10 save slots!")
        return
    else:
        try:
            amongus = int(saveline)
            amongus += 1
            amongus -= 1
        except:
            sleep(0.1)
            print("Not a valid number!")
            return
        with open(sdl, 'r') as file:
            data = file.readlines()
            data[int(saveline)] = save + '\n'
            with open(sdl, 'w') as file:
                file.writelines(data)
            sleep(0.1)
            print("Saved!")


while choosingdivision == 0:
    inp = input(
        "Pick a division!\nSWORDSMAN - Uses swords to slay foes.\nMAGE - Channels magic through staffs.\nDEFENDER - Bludgeons enemies with shields and armor. Extra defense from armor.\nARCHER - Uses bows and arrows to shoot down monsters.\n(say LOAD to load a save file)\n> ")
    inp = inp.upper()
    division = inp
    if inp == "ARCHER":
        inp = input("Choose a subdivision! or BACK\nRAPID ARCHER - Fires quickly. 30x5 Attack, 75 defense, 100 health\nLONGBOW ARCHER - Fires a slow and powerful shot. 175 Attack, 50 defense, 100 health\nSNIPER - Super accurate. 125 attack, 100 defense, 100 health.\n> ")
        inp = inp.upper()
        if inp == "RAPID ARCHER":
            subdivision = "RAPID ARCHER"
            knownattacks += ["SHOT"]
            knowndefenses += ["DODGE"]
            baseatk = 30
            basedef = 75
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "LONGBOW ARCHER":
            subdivision = "LONGBOW ARCHER"
            knownattacks += ["SHOT"]
            knowndefenses += ["DODGE"]
            baseatk = 175
            basedef = 50
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "SNIPER":
            subdivision = "SNIPER"
            knownattacks += ["SHOT"]
            knowndefenses += ["DODGE"]
            baseatk = 125
            basedef = 100
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            sleep(0.1)
            print("That isn't a subdivision!")
    elif inp == "MAGE":
        inp = input(
            "Choose a subdivision! or BACK\nCLERIC - Bonus to healing. 40 Attack, 40 defense, 300 health. 100 mp.\nWIZARD - Bonus to damaging spells. 200 Attack, 50 defense, 100 health. 125 mp.\nWARLOCK - Bonus to infliction spells. 75 attack, 75 defense, 100 health. 150 mp.\n> ")
        inp = inp.upper()
        if inp == "CLERIC":
            subdivision = "CLERIC"
            knownattacks += ["BOLT"]
            baseatk = 40
            basedef = 40
            basehp = 300
            basemp = 100
            choosingdivision = 1
        elif inp == "WIZARD":
            subdivision = "WIZARD"
            knownattacks += ["BOLT"]
            baseatk = 200
            basedef = 50
            basehp = 100
            basemp = 125
            choosingdivision = 1
        elif inp == "WARLOCK":
            subdivision = "WARLOCK"
            knownattacks += ["BOLT"]
            baseatk = 75
            basedef = 75
            basehp = 100
            basemp = 150
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            sleep(0.1)
            print("That isn't a subdivision!")
    elif inp == "SWORDSMAN":
        inp = input(
            "Choose a subdivision!\nNINJA - Has a chance to dodge attacks. 100 Attack, 75 defense, 100 health\nWIELDER - The classic swordsman. 150 Attack, 100 defense, 100 health\nBRUTE - Charges attacks to deal triple damage. 60 attack, 150 defense, 150 health\n> ")
        inp = inp.upper()
        if inp == "NINJA":
            subdivision = "NINJA"
            knownattacks += ["SLICE"]
            knowndefenses += ["CLASH"]
            baseatk = 100
            basedef = 75
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "WIELDER":
            subdivision = "WIELDER"
            knownattacks += ["SLICE"]
            knowndefenses += ["CLASH"]
            baseatk = 150
            basedef = 100
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "BRUTE":
            subdivision = "BRUTE"
            knownattacks += ["SLICE"]
            knowndefenses += ["CLASH"]
            baseatk = 60
            basedef = 150
            basehp = 150
            basemp = 0
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            sleep(0.1)
            print("That isn't a subdivision!")
    elif inp == "DEFENDER":
        inp = input(
            "Choose a subdivision!\nSPIKER - Spikes shields for more damage. 75 Attack, 200 defense, 100 health\nBULKER - A super resistant defender. 25 Attack, 300 defense, 150 health\nREFLECTOR - Uses reflective shields to minimize inflictions and reflect some attacks. 5 attack, 200 defense, 150 health\n> ")
        inp = inp.upper()
        if inp == "SPIKER":
            subdivision = "SPIKER"
            knownattacks += ["SHIELD BASH"]
            knowndefenses += ["BLOCK"]
            baseatk = 75
            basedef = 200
            basehp = 100
            basemp = 0
            choosingdivision = 1
        elif inp == "BULKER":
            subdivision = "BULKER"
            knownattacks += ["SHIELD BASH"]
            knowndefenses += ["BLOCK"]
            baseatk = 25
            basedef = 300
            basehp = 150
            basemp = 0
            choosingdivision = 1
        elif inp == "REFLECTOR":
            subdivision = "REFLECTOR"
            knownattacks += ["SHIELD BASH"]
            knowndefenses += ["BLOCK"]
            baseatk = 5
            basedef = 200
            basehp = 150
            basemp = 0
            choosingdivision = 1
        elif inp == "BACK":
            nothing = 1
        else:
            sleep(0.1)
            print("That isn't a subdivision!")
    elif inp == "LOAD":
        load()
    else:
        sleep(0.1)
        print("That isn't a division.")
sleep(0.1)
print("You set your division to " + str(division) + " and your subdivision to " + str(subdivision) + ".")
maxhp = basehp
currenthp = maxhp
dlevel = 0
dxp = 0
def updatestats():
    global dlevel
    global maxhp
    global dxp
    global knownattacks
    global knowndefenses
    global level
    global currenthp
    global basehp
    global baseatk
    global basedef
    global basemp
    global armor
    global maxmp
    global currentmp
    global inventory
    global defense
    global attack
    global tslh
    global subdivision
    global aim
    maxhp = ((level - 1) * 10) + basehp
    if subdivision == "CLERIC":
        currenthp += round(int(time.time() - tslh) * 20)
    else:
        currenthp += round(int(time.time() - tslh) * 10)
    tslh = time.time()
    if division == "MAGE":
        maxmp = ((level - 1) * 10) + basemp
    else:
        maxmp = 0
    tslh = time.time()
    if currenthp > maxhp:
        currenthp = maxhp
    if "ARMOR" in str(inventory):
        if "BASIC ARMOR" in inventory:
            armor = 1.5
        elif "LEATHER ARMOR" in inventory:
            armor = 2
        elif "COPPER ARMOR" in inventory:
            armor = 3
        elif "TITANIUM ARMOR" in inventory:
            armor = 5
        elif "GOLDEN ARMOR" in inventory:
            armor = 10
    else:
        armor = 1
    if "SWORD" in str(inventory):
        if "BASIC SWORD" in inventory:
            weapon = 1.5
            shield = 1
        elif "BROAD SWORD" in inventory:
            weapon = 2
            shield = 1
        elif "PAPER SWORD" in inventory:
            weapon = 3
            shield = 1
        elif "GLASS SWORD" in inventory:
            weapon = 5
            shield = 1
        elif "GOLDEN SWORD" in inventory:
            weapon = 10
            shield = 1
    elif "STAFF" in str(inventory):
        if "BASIC STAFF" in inventory:
            weapon = 1.5
            shield = 1
        elif "OAK STAFF" in inventory:
            weapon = 2
            shield = 1
        elif "SPRUCE STAFF" in inventory:
            weapon = 3
            shield = 1
        elif "EBONY STAFF" in inventory:
            weapon = 5
            shield = 1
        elif "GOLDEN STAFF" in inventory:
            weapon = 10
            shield = 1
    elif "SHIELD" in str(inventory):
        if "BASIC SHIELD" in inventory:
            weapon = 1
            shield = 1.25
        elif "BANDED SHIELD" in inventory:
            weapon = 1.5
            shield = 1.75
        elif "STEEL SHIELD" in inventory:
            weapon = 2
            shield = 2.5
        elif "TITANIUM SHIELD" in inventory:
            weapon = 3
            shield = 2.25
        elif "GOLDEN SHIELD" in inventory:
            weapon = 5
            shield = 3.75
    elif "BOW" in str(inventory):
        if "BASIC BOW" in inventory:
            weapon = 1.5
            shield = 1
        elif "SLENDER BOW" in inventory:
            weapon = 2
            shield = 1
        elif "STRONG BOW" in inventory:
            weapon = 3
            shield = 1
        elif "ELDER BOW" in inventory:
            weapon = 5
            shield = 1
        elif "GOLDEN BOW" in inventory:
            weapon = 10
            shield = 1
    else:
        weapon = 1
        shield = 1
    attack = round((baseatk + ((level - 1) * 5)) * weapon)
    defense = round((basedef + ((level - 1) * 5)) * armor) * shield
    prevdlevel = dlevel
    if dxp > 100:
        dlevel = 1
        if dxp > 300:
            dlevel = 2
            if dxp > 900:
                dlevel = 3
                if dxp > 2700:
                    dlevel = 4
                    if dxp > 8100:
                        dlevel = 5
                    elif subdivision == "RAPID ARCHER":
                        knownattacks = ["SHOT", "BURST", "MARK"]
                        knowndefenses = ["DASH"]
                    elif subdivision == "LONGBOW ARCHER":
                        knownattacks = ["SHARPSHOOT", "CHARGE SHARPSHOT", "CHARGE", "MARK"]
                        knowndefenses = ["DODGE"]
                    elif subdivision == "SNIPER":
                        knownattacks = ["SHARPSHOOT", "LOCK ON"]
                        knowndefenses = ["DODGE"]
                    elif subdivision == "CLERIC":
                        knownattacks = ["BOLT", "HEAL", "EMBER"]
                        knowndefenses = ["GUARDIAN SHIELD"]
                    elif subdivision == "WIZARD":
                        knownattacks = ["BEAM", "EMBER", "HEAL"]
                        knowndefenses = []
                    elif subdivision == "WARLOCK":
                        knownattacks = ["BOLT", "EMBER", "FROST", "HEAL"]
                        knowndefenses = []
                    elif subdivision == "NINJA":
                        knownattacks = ["SLICE", "SMOKE BOMB", "SUPRISE ATTACK"]
                        knowndefenses = ["SHADOW CLASH"]
                    elif subdivision == "WIELDER":
                        knownattacks = ["SLASH", "FINISHER"]
                        knowndefenses = ["PARRY"]
                    elif subdivision == "BRUTE":
                        knownattacks = ["POWER SLASH", "FOCUS POWER", "CHARGE"]
                        knowndefenses = ["POWER CLASH"]
                    elif subdivision == "SPIKER":
                        knownattacks = ["SPIKED SHIELD BASH", "SHARPEN"]
                        knowndefenses = ["THORN BLOCK"]
                    elif subdivision == "BULKER":
                        knownattacks = ["SHIELD COMBO"]
                        knowndefenses = ["COUNTER", "GUARD"]
                    elif subdivision == "REFLECTOR":
                        knownattacks = ["SHIELD BASH", "COMBO PUNCH"]
                        knowndefenses = ["BLOCK", "SHINE", "REFLECT"]

                elif subdivision == "RAPID ARCHER":
                    knownattacks = ["SHOT", "BURST", "MARK"]
                    knowndefenses = ["DASH"]
                elif subdivision == "LONGBOW ARCHER":
                    knownattacks = ["SHARPSHOOT", "CHARGE SHOT", "CHARGE", "MARK"]
                    knowndefenses = ["DODGE"]
                elif subdivision == "SNIPER":
                    knownattacks = ["SHARPSHOOT", "LOCK ON"]
                    knowndefenses = ["DODGE"]
                elif subdivision == "CLERIC":
                    knownattacks = ["BOLT", "HEAL", "EMBER"]
                    knowndefenses = ["GUARDIAN SHIELD"]
                elif subdivision == "WIZARD":
                    knownattacks = ["BEAM", "EMBER", "HEAL"]
                    knowndefenses = []
                elif subdivision == "WARLOCK":
                    knownattacks = ["BOLT", "EMBER", "FROST", "HEAL"]
                    knowndefenses = []
                elif subdivision == "NINJA":
                    knownattacks = ["SLICE", "SMOKE BOMB", "SUPRISE ATTACK"]
                    knowndefenses = ["SHADOW CLASH"]
                elif subdivision == "WIELDER":
                    knownattacks = ["SLASH", "FINISHER"]
                    knowndefenses = ["PARRY"]
                elif subdivision == "BRUTE":
                    knownattacks = ["POWER SLICE", "CHARGE", "FOCUS POWER"]
                    knowndefenses = ["POWER CLASH"]
                elif subdivision == "SPIKER":
                    knownattacks = ["SPIKED SHIELD BASH", "SHARPEN"]
                    knowndefenses = ["THORN BLOCK"]
                elif subdivision == "BULKER":
                    knownattacks = ["SHIELD COMBO"]
                    knowndefenses = ["COUNTER", "GUARD"]
                elif subdivision == "REFLECTOR":
                    knownattacks = ["SHIELD BASH"]
                    knowndefenses = ["BLOCK", "SHINE", "REFLECT"]

            elif subdivision == "RAPID ARCHER":
                knownattacks = ["SHOT", "BURST", "MARK"]
                knowndefenses = ["DODGE"]
            elif subdivision == "LONGBOW ARCHER":
                knownattacks = ["SHOT", "CHARGE SHOT", "CHARGE", "MARK"]
                knowndefenses = ["DODGE"]
            elif subdivision == "SNIPER":
                knownattacks = ["SHOT", "LOCK ON"]
                knowndefenses = ["DODGE"]
            elif subdivision == "CLERIC":
                knownattacks = ["BOLT", "HEAL", "EMBER"]
                knowndefenses = []
            elif subdivision == "WIZARD":
                knownattacks = ["BEAM", "EMBER"]
                knowndefenses = []
            elif subdivision == "WARLOCK":
                knownattacks = ["BOLT", "EMBER", "FROST"]
                knowndefenses = []
            elif subdivision == "NINJA":
                knownattacks = ["SLICE", "SMOKE BOMB"]
                knowndefenses = ["SHADOW CLASH"]
            elif subdivision == "WIELDER":
                knownattacks = ["SLASH", "FINISHER"]
                knowndefenses = ["CLASH"]
            elif subdivision == "BRUTE":
                knownattacks = ["POWER SLICE", "FOCUS POWER", "CHARGE"]
                knowndefenses = ["CLASH"]
            elif subdivision == "SPIKER":
                knownattacks = ["SPIKED SHIELD BASH"]
                knowndefenses = ["THORN BLOCK"]
            elif subdivision == "BULKER":
                knownattacks = ["SHIELD COMBO"]
                knowndefenses = ["BLOCK", "GUARD"]
            elif subdivision == "REFLECTOR":
                knownattacks = ["SHIELD BASH", "PUNCH"]
                knowndefenses = ["BLOCK", "SHINE"]

        elif subdivision == "RAPID ARCHER":
            knownattacks = ["SHOT", "BURST"]
            knowndefenses = ["DODGE"]
        elif subdivision == "LONGBOW ARCHER":
            knownattacks = ["SHOT", "CHARGE SHOT", "CHARGE"]
            knowndefenses = ["DODGE"]
        elif subdivision == "SNIPER":
            knownattacks = ["SHOT", "MARK"]
            knowndefenses = ["DODGE"]
        elif subdivision == "CLERIC":
            knownattacks = ["BOLT", "HEAL"]
            knowndefenses = []
        elif subdivision == "WIZARD":
            knownattacks = ["BEAM"]
            knowndefenses = []
        elif subdivision == "WARLOCK":
            knownattacks = ["BOLT", "EMBER"]
            knowndefenses = []
        elif subdivision == "NINJA":
            knownattacks = ["SLICE", "SMOKE BOMB"]
            knowndefenses = ["CLASH"]
        elif subdivision == "WIELDER":
            knownattacks = ["SLASH"]
            knowndefenses = ["CLASH"]
        elif subdivision == "BRUTE":
            knownattacks = ["POWER SLICE", "CHARGE"]
            knowndefenses = ["CLASH"]
        elif subdivision == "SPIKER":
            knownattacks = ["SPIKED SHIELD BASH"]
            knowndefenses = ["BLOCK"]
        elif subdivision == "BULKER":
            knownattacks = ["SHIELD BASH"]
            knowndefenses = ["BLOCK", "GUARD"]
        elif subdivision == "REFLECTOR":
            knownattacks = ["SHIELD BASH"]
            knowndefenses = ["BLOCK", "SHINE"]
    if dlevel != prevdlevel:
        sleep(0.1)
        print("You leveled up in division!!\nCombat options :\n" + str(knownattacks) + "\n" + str(knowndefenses))


def startbounty():
    global division
    global subdivision
    global basehp
    global baseatk
    global basedef
    global basemp
    global tslq
    global bountydefinitions
    global bountyready
    global bounty
    global wonbounty
    global totalgold
    global dxp
    sleep(0.1)
    print("You read the bounty board.")
    if (time.time() - tslq) > 1200:
        bountyready = 1
    else:
        sleep(0.1)
        print("There are no new bounties. Next bounty available in " + str(1200 - (time.time() - tslq)) + " seconds.")
        return
    if bountyready == 1:
        sleep(0.1)
        print("A bounty is available!")
        bounty = randrange(1, 9)
        sleep(0.1)
        print(bountydescriptions[bounty])
        inp = input("Would you like to begin the bounty? (YES/NO)\n> ")
        inp = inp.upper()
        if inp == "YES":
            sleep(0.1)
            print("You begin the bounty..")
            sleep(0.1)
            print(bountydefinitions[bounty])
            input("Press enter to continue.")
            fight()
            if wonbounty == 1:
                gdxp = randrange(75, 200)
                if bounty == 1:
                    gg = round(randrange(totalgold * 0.05, totalgold * 0.1))
                    sleep(0.1)
                    print("You defeated the goliath! You gained " + gdxp + " division experience and " + gg + " gold!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 2:
                    gdxp += 50
                    gg = (randrange(round(totalgold * 0.025), round(totalgold * 0.075)))
                    sleep(0.1)
                    print(f"You defeated the goblins! You gained {gdxp} division experience and got {gg} gold!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 3:
                    gg = round(randrange(totalgold * 0.075, totalgold * 0.1))
                    sleep(0.1)
                    print(
                        f"You defeated the slime boss! You gained {gdxp} division experience. You gave the monster parts and got {gg} gold!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 4:
                    gdxp += 25
                    gg = round(randrange(totalgold * 0.05, totalgold * 0.1))
                    sleep(0.1)
                    print(f"You defeated the trolls! You gained {gdxp} division experience. You were paid {gg} gold!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 5:
                    gdxp += 25
                    gg = round(randrange(totalgold * 0.2, totalgold * 0.1))
                    sleep(0.1)
                    print(f"You defeated the dragon! You gained {gdxp} division experience. You were paid {gg} gold!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 6:
                    gdxp += 10
                    gg = round(randrange(totalgold * 0.15, totalgold * 0.1))
                    sleep(0.1)
                    print(
                        f"You defeated the werewolf! You gained {gdxp} division experience. You were paid {gg} gold for the fruit!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 7:
                    gdxp = 0
                    gg = round(randrange(int(totalgold * 0.25), int(totalgold * 0.15)))
                    sleep(0.1)
                    print(f"You won the quiz! you were paid {gg} gold.")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 8:
                    gg = round(randrange(int(totalgold * 0.25), int(totalgold * 0.09)))
                    sleep(0.1)
                    print(f"You defeated the mimic! You gained {gdxp} division experience. You were paid {gg} gold!")
                    totalgold += gg
                    dxp += gdxp
                elif bounty == 9:
                    gdxp = round(gdxp * 1.5)
                    gg = round(randrange(int(totalgold * 0.025), int(totalgold * 0.015)))
                    sleep(0.1)
                    print(f"You defeated the buffalo! you were paid {gg} gold and gained {gdxp} division experience.")
                    totalgold += gg
                    dxp += gdxp
            else:
                sleep(0.1)
                print("Bounty failed!! A new one will be available in 20 minutes.")
            bountyready = 0
            tslq = time.time()
        else:
            sleep(0.1)
            print("You left the bounty board. A new bounty will be available in 20 minutes!")
            bountyready = 0
            tslq = time.time()


def fight():
    global bounty
    global subdivision
    global bountymonsters
    global level
    global currenthp
    global maxmp
    global currentmp
    global currenthp
    global inventory
    global defense
    global attack
    global knownattacks
    global wonbounty
    global knowndefenses
    bounty = 7
    if bounty == 7:
        correct = 0
        sleep(0.1)
        print("You encountered THE QUIZMASTER!")
        sleep(0.1)
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("How much hp do you have?\n> ")
        if str(inp) == str(currenthp):
            sleep(0.1)
            print("SUCCESS!")
            correct += 1
        else:
            sleep(0.1)
            print("FAILED.. You have " + str(currenthp) + " health right now.")
        sleep(0.1)
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("What is your subdivision?\n> ")
        if str(inp.upper) == str(subdivision):
            sleep(0.1)
            print("SUCCESS!")
            correct += 1
        else:
            sleep(0.1)
            print(f"FAILED.. Your subdivision is {subdivision}.")
        sleep(0.1)
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("1 or 2?\n> ")
        ca = randrange(1, 2)
        if inp == str(ca):
            sleep(0.1)
            print("SUCCESS!")
            correct += 1
        else:
            sleep(0.1)
            print(f"FAILED.. The answer was {ca}!")
        sleep(0.1)
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("What's up?\n> ")
        sleep(0.1)
        print("SUCCESS!")
        correct += 1
        sleep(0.1)
        print("THE QUIZMASTER ASKS A QUESTION!")
        inp = input("Name an attack you have!\n> ")
        if inp.upper in knownattacks:
            sleep(0.1)
            print("SUCCESS!")
            correct += 1
        else:
            sleep(0.1)
            print(f"FAILED.. You could have answered the following: {knownattacks}!")
        if correct > randrange(2, 3):
            sleep(0.1)
            print("You win the quiz. Thanks for playing!")
            wonbounty = 1
            return
        else:
            sleep(0.1)
            print("You failed the quiz.. Thanks for playing!")
            wonbounty = 0
            return
    else:
        updatestats()
        global monsterhp
        global dlevel
        monsterhp = maxhp * (randrange(3, 7)) * dlevel
        global monsterdmg
        monsterdmg = monsterhp / 400
        global monster
        monster = bountymonsters[bounty]
        global charge
        charge = 0
        global monsteraction
        monsteraction = "odjvnso"
        global smoke
        smoke = 0
        global freeze
        freeze = 0
        currentmp = maxmp
        global burn
        burn = 0
        global combo
        combo = 0
        global targeted
        targeted = 0
        global canreflect
        canreflect = 0
        global run
        global doused
        doused = 0
        run = 0
        sleep(0.1)
        print("You encountered " + monster + "!")
        turn()


def turn():
    global run
    global monster
    global canreflect
    global targeted
    global monsterhp
    global burn
    global combo
    global freeze
    global currenthp
    global currentmp
    global maxmp
    global smoke
    global monsteraction
    global monsterdmg
    global charge
    global bounty
    global subdivision
    global bountymonsters
    global level
    global monsterdmg
    global currenthp
    global doused
    global maxmp
    global currentmp
    global currenthp
    global inventory
    global defense
    global attack
    global knownattacks
    global wonbounty
    global knowndefenses
    if run > 0:
        return
    if monsterhp < 1:
        wonbounty = 1
        return
    if currenthp < 1:
        wonbounty = 0
        return
    sleep(0.1)
    print(f"-------{str(monster)} -------")
    sleep(0.1)
    print(str(monsterhp) + " health")
    sleep(0.1)
    print(str(monsterdmg) + " attack")
    sleep(0.1)
    print(f"------- YOU -------")
    sleep(0.1)
    print(str(currenthp) + " health")
    sleep(0.1)
    print(str(attack) + " attack")
    sleep(0.1)
    print("-------------------")
    if maxmp > 0:
        if maxmp != currentmp:
            currentmp += 25
            sleep(0.1)
            print("You regained some mp.")
            if currentmp > maxmp:
                currentmp = maxmp
                sleep(0.1)
                print(str(currentmp) + " mp")
    sleep(0.1)
    print(str(attack) + " attack")
    if smoke == 1:
        sleep(0.1)
        print("The smoke cleared...")
        smoke = 0
    elif smoke == 2:
        smoke = 1
    if burn > 0:
        sleep(0.1)
        print("The enemy was dealt " + monsterhp * 0.01 + " damage from burn!")
        monsterhp -= monsterhp * 0.01
        burn -= 1
        if burn == 0:
            sleep(0.1)
            print("The burn wore off...")
    if targeted > 0:
        targeted -= 1
        if targeted == 0:
            sleep(0.1)
            print("Your accuracy boost wore off...")
    inputingmove = 1
    while inputingmove == 1:
        inp = input("What do you do?\nATTACK || DEFEND || ITEM || RUN\n> ")
        inp = inp.upper()
        if inp == "RUN":
            sleep(0.1)
            print("You ran!")
            sleep(0.1)
            print("You lost the bounty...")
            run = 1
            wonbounty = 0
            return
        elif inp == "ATTACK":
            inp = input("Pick an attack:\n" + str(knownattacks) + "\n> ").upper()
            if inp in knownattacks:
                sleep(0.1)
                print("You used " + inp + "!")
                inputingmove = 0
            else:
                sleep(0.1)
                print("That isn't an attack!")
                continue
        elif inp == "DEFEND":
            inp = input("Pick an defense:\n" + str(knowndefenses) + "\n> ").upper()
            if inp in knowndefenses:
                sleep(0.1)
                print("You used " + inp + "!")
                inputingmove = 0
            else:
                sleep(0.1)
                print("That isn't a defense!")
                continue
        elif inp == "ITEM":
            inp = input(F"What item would you like to use?\n{str(inventory)}\n> ").upper()
            if inp in inventory:
                if inp == "BOMB":
                    sleep(0.1)
                    print("You used " + inp + "!")
                    inputingmove = 0
                elif inp == "ROPE":
                    sleep(0.1)
                    print("You used " + inp + "!")
                    inputingmove = 0
                elif inp == "LAMP OIL":
                    sleep(0.1)
                    print("You used " + inp + "!")
                    inputingmove = 0
                else:
                    sleep(0.1)
                    print("That isn't a useable item!!")
                    continue
            else:
                sleep(0.1)
                print("That isn't an item you have!")
                continue
        else:
            sleep(0.1)
            print("That isn't an option!")
            continue
    if 1 == 1:
        prevmonsteraction = monsteraction
        if run > 0:
            return
        if monsterhp < 1:
            wonbounty = 1
            return
        if currenthp < 1:
            wonbounty = 0
            return
        if freeze > 0:
            sleep(0.1)
            print("The enemy is frozen!")
            monsteraction = "frozen"
            freeze -= 1
            if freeze == 0:
                sleep(0.1)
                print("The enemy warmed up...")
        else:
            monsteraction = random.choice(["attacks", "blocks", "dodges"])
            sleep(0.1)
            print("The enemy " + str(monsteraction) + "!")
        if monsteraction == "blocks":
            try:
                r = randrange(1, 3)
                if inp in knownattacks:
                    if inp == "HEAL":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    if inp == "SMOKE BOMB":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    if inp == "MARK":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    if inp == "LOCK ON":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    elif inp == "SUPRISE ATTACK":
                        sleep(0.1)
                        print("...but the enemy saw no attack to block!")
                    elif r == 1:
                        sleep(0.1)
                        print("The enemy parried your " + str(inp) + "!")
                        sleep(0.1)
                        print("You lost " + str(round(int(monsterdmg * 0.75))) + " health!")
                        currenthp -= round(monsterdmg * 0.75)
                        turn()
                    elif r == 2:
                        sleep(0.1)
                        print("The enemy blocked your " + str(inp) + "!")
                        turn()
                    elif r == 3:
                        sleep(0.1)
                        print("The block failed!")
                else:
                    sleep(0.1)
                    print("..but there was no attack to block")
            except:
                sleep(0.1)
                print("..but there was no attack to block")
        if monsteraction == "dodges":
            try:
                if inp in knownattacks:
                    if inp == "HEAL":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    if inp == "SMOKE BOMB":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    if inp == "MARK":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    if inp == "LOCK ON":
                        sleep(0.1)
                        print("..but there was no attack to block")
                    elif inp == "SUPRISE ATTACK":
                        sleep(0.1)
                        print("...but the enemy saw no attack to block!")
                    elif randrange(1, 2) == 1:
                        sleep(0.1)
                        print("The enemy dodges your " + str(inp) + "!")
                        turn()
                    else:
                        sleep(0.1)
                        print("The enemy dodged, but still got hit!")
                else:
                    sleep(0.1)
                    print("..but there was no attack to dodge")
            except:
                sleep(0.1)
                print("..but there was no attack to dodge")
        if monsteraction == "attacks":
            if prevmonsteraction == "dodges":
                sleep(0.1)
                print("The enemy pulled out of a dodge into a DODGE ATTACK")
                if subdivision == "NINJA":
                    if randrange(1, 4) == 4:
                        print("Your INNATE: NINJA SENSE allowed you to dodge the attack!")
                elif smoke == 1:
                    if randrange(1, 3) == 3:
                        sleep(0.1)
                        print("...but the enemy couldn't find you in the smoke!")
                    else:
                        if inp not in knowndefenses:
                            losthp = round(monsterdmg * (defense / 450))
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            losthp = round((monsterdmg * (defense / 450)) / 2)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health! You couldn't fully block the dodge attack.")
                            currenthp -= losthp
                elif inp not in knowndefenses:
                    losthp = round(monsterdmg * (defense / 450))
                    sleep(0.1)
                    print("You lost " + str(losthp) + " health!")
                    currenthp -= losthp
                else:
                    losthp = round(monsterdmg * (defense / 450) / 2)
                    sleep(0.1)
                    print("You lost " + str(losthp) + " health! You couldn't fully block the dodge attack.")
                    currenthp -= losthp
            else:
                if subdivision == "NINJA":
                    if randrange(1, 4) == 4:
                        print("Your INNATE: NINJA SENSE allowed you to dodge the attack!")
                elif smoke > 0:
                    if randrange(1, 3) == 3:
                        sleep(0.1)
                        print("...but the enemy couldn't find you in the smoke!")
                    elif inp in knowndefenses:
                        if inp == "BLOCK":
                            sleep(0.1)
                            print("You BLOCK the enemy's attack!")
                            if randrange(1, 3) == 3:
                                sleep(0.1)
                                print("The block failed!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print("Success!")
                                if canreflect == 1:
                                    sleep(0.1)
                                    print("Your shiny shield reflects the attack!")
                                    sleep(0.1)
                                    print("The shine went away..")
                                    sleep(0.1)
                                    print(f"You dealt {monsterdmg * 2} damage back!")
                                    monsterhp -= monsterdmg * 2
                                    canreflect = 0
                        elif inp == "CLASH":
                            sleep(0.1)
                            print("You CLASH with the enemy's attack!")
                            if randrange(1, 2) == 2:
                                sleep(0.1)
                                print("The clash failed!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print("Success!")
                        elif inp == "THORN BLOCK":
                            sleep(0.1)
                            print("You THORN BLOCK the enemy's attack!")  # depends on defense + shine
                            if randrange(1, 4) == 3:
                                sleep(0.1)
                                print("The block failed!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print(f"Success! You dealt {round(0.2 * attack)} damage with thorns!")
                                monsterhp -= round(0.2 * attack)
                                if canreflect == 1:
                                    sleep(0.1)
                                    print("Your shiny shield reflects the attack!")
                                    sleep(0.1)
                                    print("The shine went away..")
                                    sleep(0.1)
                                    print(f"You dealt {monsterdmg * 2} damage back!")
                                    monsterhp -= monsterdmg * 2
                                    canreflect = 0
                        elif inp == "COUNTER":
                            sleep(0.1)
                            print("You COUNTER the enemy's attack!")
                            if randrange(1, 4) == 3:
                                sleep(0.1)
                                print("The counter failed!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print(f"Success! You countered the attack and dealt {round(0.5 * attack)} damage!")
                                monsterhp -= round(0.2 * attack)
                        elif inp == "SHADOW CLASH":
                            sleep(0.1)
                            print("You SHADOW CLASH with the enemy's attack!")  # depends on defense + shine
                            if smoke == 0:
                                sleep(0.1)
                                print("...but the enemy easily saw it coming!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print(f"In a haze of smoke, the enemy swings wildly...")
                                sleep(2)
                                sleep(0.1)
                                print("You SHADOW CLASH!")
                                if randrange(1, 7) == 7:
                                    sleep(0.1)
                                    print("The SHADOW CLASH failed!")
                                    sleep(0.1)
                                    print("You fade into the smoke...")
                                else:
                                    sleep(0.1)
                                    print(
                                        f"Success! You clashed with the attack and dealt {round(attack * 1.25)} damage!")
                                    monsterhp -= round(0.2 * attack)
                        elif inp == "POWER CLASH":
                            sleep(0.1)
                            print("You POWER CLASH with the enemy's attack!")
                            if charge == 0:
                                sleep(0.1)
                                print("...but you weren't charged up for the clash!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print(f"You POWER CLASH!")
                                if randrange(1, 6) == 6:
                                    sleep(0.1)
                                    print("The POWER CLASH failed!")
                                    losthp = round(monsterdmg)
                                    sleep(0.1)
                                    print("You lost " + str(losthp) + " health!")
                                    currenthp -= losthp
                                else:
                                    sleep(0.1)
                                    print(f"Success! You clashed with the attack and dealt {round(attack * 3)} damage!")
                                    monsterhp -= round(3 * attack)
                    else:
                        losthp = round(monsterdmg)
                        sleep(0.1)
                        print("You lost " + str(losthp) + " health!")
                        currenthp -= losthp
                elif inp in knowndefenses:
                    if inp == "BLOCK":
                        sleep(0.1)
                        print("You BLOCK the enemy's attack!")
                        if randrange(1, 3) == 3:
                            sleep(0.1)
                            print("The block failed!")
                            losthp = round(monsterdmg)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            sleep(0.1)
                            print("Success!")
                            if canreflect == 1:
                                sleep(0.1)
                                print("Your shiny shield reflects the attack!")
                                sleep(0.1)
                                print("The shine went away..")
                                sleep(0.1)
                                print(f"You dealt {monsterdmg * 2} damage back!")
                                monsterhp -= monsterdmg * 2
                                canreflect = 0
                    elif inp == "CLASH":
                        sleep(0.1)
                        print("You CLASH with the enemy's attack!")
                        if randrange(1, 2) == 2:
                            sleep(0.1)
                            print("The clash failed!")
                            losthp = round(monsterdmg)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            sleep(0.1)
                            print("Success!")
                    elif inp == "THORN BLOCK":
                        sleep(0.1)
                        print("You THORN BLOCK the enemy's attack!")  # depends on defense + shine
                        if randrange(1, 4) == 3:
                            sleep(0.1)
                            print("The block failed!")
                            losthp = round(monsterdmg)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            sleep(0.1)
                            print(f"Success! You dealt {round(0.2 * attack)} damage with thorns!")
                            monsterhp -= round(0.2 * attack)
                            if canreflect == 1:
                                sleep(0.1)
                                print("Your shiny shield reflects the attack!")
                                sleep(0.1)
                                print("The shine went away..")
                                sleep(0.1)
                                print(f"You dealt {monsterdmg * 2} damage back!")
                                monsterhp -= monsterdmg * 2
                                canreflect = 0
                    elif inp == "COUNTER":
                        sleep(0.1)
                        print("You COUNTER the enemy's attack!")
                        if randrange(1, 4) == 3:
                            sleep(0.1)
                            print("The counter failed!")
                            losthp = round(monsterdmg)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            sleep(0.1)
                            print(f"Success! You countered the attack and dealt {round(0.5 * attack)} damage!")
                            monsterhp -= round(0.2 * attack)
                    elif inp == "SHADOW CLASH":
                        sleep(0.1)
                        print("You SHADOW CLASH with the enemy's attack!")  # depends on defense + shine
                        if smoke == 0:
                            sleep(0.1)
                            print("...but the enemy easily saw it coming!")
                            losthp = round(monsterdmg)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            sleep(0.1)
                            print(f"In a haze of smoke, the enemy swings wildly...")
                            sleep(2)
                            sleep(0.1)
                            print("You SHADOW CLASH!")
                            if randrange(1, 7) == 7:
                                sleep(0.1)
                                print("The SHADOW CLASH failed!")
                                sleep(0.1)
                                print("You fade into the smoke...")
                            else:
                                sleep(0.1)
                                print(f"Success! You clashed with the attack and dealt {round(attack * 1.25)} damage!")
                                monsterhp -= round(0.2 * attack)
                    elif inp == "POWER CLASH":
                        sleep(0.1)
                        print("You POWER CLASH with the enemy's attack!")
                        if charge == 0:
                            sleep(0.1)
                            print("...but you weren't charged up for the clash!")
                            losthp = round(monsterdmg)
                            sleep(0.1)
                            print("You lost " + str(losthp) + " health!")
                            currenthp -= losthp
                        else:
                            sleep(0.1)
                            print(f"You POWER CLASH!")
                            if randrange(1, 6) == 6:
                                sleep(0.1)
                                print("The POWER CLASH failed!")
                                losthp = round(monsterdmg)
                                sleep(0.1)
                                print("You lost " + str(losthp) + " health!")
                                currenthp -= losthp
                            else:
                                sleep(0.1)
                                print(f"Success! You clashed with the attack and dealt {round(attack * 3)} damage!")
                                monsterhp -= round(3 * attack)
                    else:
                        sleep(0.1)
                        print(f"The enemy didn't attack, so you couldn't use {inp}!")
                else:
                    losthp = round(monsterdmg)
                    sleep(0.1)
                    print("You lost " + str(losthp) + " health!")
                    currenthp -= losthp
        if run > 0:
            return
        if monsterhp < 1:
            wonbounty = 1
            return
        if currenthp < 1:
            wonbounty = 0
            return
        if inp in knownattacks:
            if inp == "SHIELD BASH":
                sleep(0.1)
                print("You SHIELD BASH!")
                sleep(0.1)
                print("You dealt " + str(attack) + " damage.")
                monsterhp -= attack
            elif inp == "SPIKED SHIELD BASH":
                sleep(0.1)
                print("You SHIELD BASH!")
                sleep(0.1)
                print("You dealt " + str(attack * 1.5) + " damage.")
                monsterhp -= attack * 1.5
            elif inp == "CHARGE":
                if charge == 1:
                    sleep(0.1)
                    print("You can't charge further!")
                else:
                    sleep(0.1)
                    print("You CHARGE!")
                    sleep(0.1)
                    print("You are charged up for a powerful attack!")
                    charge = 1
            elif inp == "POWER SLICE":
                sleep(0.1)
                print("You POWER SLICE!")
                if charge == 1:
                    sleep(0.1)
                    print("You dealt " + str(attack * 3) + " damage.")
                    monsterhp -= attack * 3
                    charge = 0
                else:
                    sleep(0.1)
                    print("You POWER SLICE!")
                    sleep(0.1)
                    print("...you weren't charged for this attack!")
            elif inp == "SLASH":
                sleep(0.1)
                print("You SLASH!")
                sleep(0.1)
                print("You dealt " + str(attack * 1.5) + " damage.")
                monsterhp -= attack * 1.5
            elif inp == "SMOKE BOMB":
                sleep(0.1)
                print("You throw a SMOKE BOMB!")
                sleep(0.1)
                print("The battlefield was filled with smoke...")
                smoke = 2
            elif inp == "SUPRISE ATTACK":
                sleep(0.1)
                print("You make a SUPRISE ATTACK!")
                if smoke > 0:
                    sleep(0.1)
                    print("You are clouded in smoke...")
                    sleep(2)
                    sleep(0.1)
                    print("The enemy didn't know what hit them.")
                    sleep(0.1)
                    monsterhp -= attack * 2 * smoke
                else:
                    sleep(0.1)
                    print("...but the enemy blocked your move because you were easy to spot!")
                smoke = 1
            elif inp == "BOLT":
                if currentmp > 14:
                    sleep(0.1)
                    print("You fire a BOLT for 15 mp!")
                    sleep(0.1)
                    print("You dealt " + str(attack) + " damage.")
                    if subdivision == "WIZARD":
                        print(f"Your INNATE: FOCUS PRISM allowed you to deal {round(attack * 0.25)} extra damage!")
                        monsterhp -= round(attack * 0.25)
                    currentmp -= 15
                    monsterhp -= attack
                else:
                    sleep(0.1)
                    print("You don't have enough mp...")
            elif inp == "EMBER":
                if currentmp > 49:
                    sleep(0.1)
                    print("You fire an EMBER for 50 mp!")
                    sleep(0.1)
                    print("The enemy was burned!")
                    if doused == 1:
                        sleep(0.1)
                        print("The enemy was SET ABLAZE by the lamp oil!")
                        doused = 0
                        burndmg = round(randrange(5, 10) * attack * 1.2)
                        sleep(0.1)
                        print(f"The enemy put itself out after losing {burndmg} health!")
                        monsterhp -= burndmg
                    else:
                        burn = 2
                        if subdivision == "WIZARD":
                            print(f"Your INNATE: INFLICTOR allowed you to inflict more burn duration!")
                            burn += randrange(1, 2)
                else:
                    sleep(0.1)
                    print("You don't have enough mp...")
            elif inp == "FROST":
                if currentmp > 49:
                    sleep(0.1)
                    print("You summon a FROST for 50 mp!")
                    if randrange(1, 2) == 1:
                        sleep(0.1)
                        print("The enemy was frozen!")
                        freeze = 1
                    else:
                        if subdivision == "WIZARD":
                            if randrange(1, 2) == 1:
                                print(f"Your INNATE: INFLICTOR allowed you to freeze the enemy when it would have normally been unbothered!")
                                freeze = 1
                            else:
                                sleep(0.1)
                                print("The enemy was unbothered by the cold.")
                        sleep(0.1)
                        print("The enemy was unbothered by the cold.")
                else:
                    sleep(0.1)
                    print("You don't have enough mp...")
            elif inp == "BEAM":
                if currentmp > 59:
                    sleep(0.1)
                    print("You fire a BEAM for 60 mp!")
                    sleep(0.1)
                    print("You dealt " + str(attack) * 1.6 + " damage.")
                    if subdivision == "WIZARD":
                        print(f"Your INNATE: FOCUS PRISM allowed you to deal {round(attack * 1.6 * 0.25)} extra damage!")
                        monsterhp -= round(attack * 1.6 * 0.25)
                    currentmp -= 60
                    monsterhp -= attack * 1.6
                else:
                    sleep(0.1)
                    print("You don't have enough mp...")
            elif inp == "HEAL":
                if currentmp > 39:
                    sleep(0.1)
                    print("You heal yourself for 40 mp!")
                    sleep(0.1)
                    print("You healed " + str(maxhp * 0.25) + " damage.")
                    currentmp -= 40
                    currenthp += maxhp * 0.25
                    if subdivision == "CLERIC":
                        print(f"Your INNATE: MEDICINAL allowed you to gain {(maxhp * 0.25) * 0.5} extra health!")
                        currenthp += maxhp * 0.25 * 0.5
                    if currenthp > maxhp:
                        currenthp = maxhp
                else:
                    sleep(0.1)
                    print("You don't have enough mp...")
            elif inp == "SHOT":
                sleep(0.1)
                print("You shoot a SHOT!")
                if targeted > 0:
                    if randrange(1, 6) == 6:
                        sleep(0.1)
                        if subdivision == "SNIPER":
                            if randrange(1, 3) == 3:
                                print("Your INNATE: DEADEYE kept you from missing the shot!")
                                print("You dealt " + str(round(attack * 1.5)) + " damage.")
                                monsterhp -= round(attack * 1.5)
                            else:
                                print("MISS!")
                        else:
                            print("MISS!")
                    else:
                        sleep(0.1)
                        print("HIT! You dealt " + str(round(attack * 1.5)) + " damage.")
                        monsterhp -= round(attack * 1.5)
                elif randrange(1, 4) == 4:
                    sleep(0.1)
                    print("MISS!")
                else:
                    sleep(0.1)
                    print("HIT! You dealt " + str(round(attack * 1.5)) + " damage.")
                    monsterhp -= round(attack * 1.5)
            elif inp == "SHARPSHOOT":
                sleep(0.1)
                print("You SHARPSHOOT!")
                if targeted > 0:
                    if randrange(1, 8) == 8:
                        sleep(0.1)
                        if subdivision == "SNIPER":
                            if randrange(1, 3) == 3:
                                print("Your INNATE: DEADEYE kept you from missing the shot!")
                                print("You dealt " + str(round(attack * 2)) + " damage.")
                                monsterhp -= round(attack * 2)
                            else:
                                print("MISS!")
                        print("MISS!")
                    else:
                        sleep(0.1)
                        print("HIT! You dealt " + str(attack * 2) + " damage.")
                        monsterhp -= attack * 2
                elif randrange(1, 6) == 6:
                    sleep(0.1)
                    if subdivision == "SNIPER":
                        if randrange(1, 3) == 3:
                            print("Your INNATE: DEADEYE kept you from missing the shot!")
                            print("You dealt " + str(round(attack * 2)) + " damage.")
                            monsterhp -= round(attack * 2)
                        else:
                            print("MISS!")
                    print("MISS!")
                else:
                    sleep(0.1)
                    print("HIT! You dealt " + str(attack * 2) + " damage.")
                    monsterhp -= attack * 2
            elif inp == "MARK":
                sleep(0.1)
                print("You MARK the enemy. You are more accurate now!")
                targeted = 2
            elif inp == "LOCK ON":
                sleep(0.1)
                print("You LOCK ON to the enemy. You are more accurate now!")
                targeted = 3
            elif inp == "CHARGE SHOT":
                if charge == 1:
                    if targeted > 0:
                        if randrange(1, 7) == 7:
                            sleep(0.1)
                            print("MISS!")
                        else:
                            sleep(0.1)
                            print("HIT! You dealt " + str(attack * 3) + " damage.")
                            monsterhp -= attack * 3
                    elif randrange(1, 5) == 5:
                        sleep(0.1)
                        print("You dealt " + str(attack * 3) + " damage!")
                        monsterhp -= attack * 3
                        charge = 0
                    else:
                        sleep(0.1)
                        print("You missed!")
                else:
                    sleep(0.1)
                    print("You CHARGE SHOT!")
                    sleep(0.1)
                    print("...you weren't charged for this attack")
            elif inp == "BURST":
                sleep(0.1)
                print("You shoot a BURST!")
                hits = 0
                for i in 3:
                    if targeted > 0:
                        if randrange(1, 6) == 6:
                            sleep(0.1)
                            print("MISS!")
                        else:
                            sleep(0.1)
                            print("HIT!")
                            hits += 1
                    elif randrange(1, 4) == 4:
                        sleep(0.1)
                        print("MISS!")
                    else:
                        sleep(0.1)
                        print("HIT!")
                        hits += 1
                sleep(0.1)
                print("You hit " + str(hits) + " shots and dealt " + attack * hits + " damage!")
                monsterhp -= attack * hits
            elif inp == "PUNCH":
                sleep(0.1)
                print("You PUNCH!")
                sleep(0.1)
                print("You dealt " + str(round(attack * 0.75)) + " damage.")
                monsterhp -= round(attack * 0.75)
            elif inp == "SHINE":
                sleep(0.1)
                print("You SHINE!")
                shine = 1
                sleep(0.1)
                print("Your shield became shiny.")
            elif inp == "SHIELD COMBO":
                sleep(0.1)
                print("You SHIELD COMBO!")
                combo += 1
                sleep(0.1)
                print(str(combo) + "x COMBO!")
                sleep(0.1)
                print("You dealt " + str(attack * combo) + " damage.")
                monsterhp -= attack * combo
            elif inp == "COMBO PUNCH":
                sleep(0.1)
                print("You COMBO PUNCH!")
                combo += 1
                sleep(0.1)
                print(str(combo) + "x COMBO!")
                sleep(0.1)
                print("You dealt " + str(attack * combo) + " damage.")
                monsterhp -= attack * combo
            elif inp == "FOCUS POWER":
                sleep(0.1)
                print("You focus your power...")
                attack = attack * 1.2
                sleep(0.1)
                print("Your attack increased!")
            elif inp == "SHARPEN":
                sleep(0.1)
                print("You sharpen your shield's spikes...")
                attack = attack * 1.2
                sleep(0.1)
                print("Your attack increased!")
            elif inp == "FINISHER":
                sleep(0.1)
                print("You swing a finishing blow!!")
                if monsterhp < randrange(750, 1250):
                    sleep(0.1)
                    print("INSTAKILL!!")
                    monsterhp = 0
                else:
                    sleep(0.1)
                    print("The enemy had too much hp to kill!")
        elif inp in knowndefenses:
            if inp == "GUARDIAN SHIELD":
                if currentmp > 49:
                    sleep(0.1)
                    print("You create a GUARDIAN SHIELD!")
                    defense = round(defense * 1.25)
                    sleep(0.1)
                    print("Your defense increased!")
                else:
                    sleep(0.1)
                    print("You try to create a guardian shield, you don't have enough mp to use that...")
            if inp == "GUARD":
                sleep(0.1)
                print("You GUARD!")
                defense += monsterdmg * 0.1
                sleep(0.1)
                print("Your defense was raised!")
        if inp == "SHINE":
            sleep(0.1)
            print("You SHINE your shield!!")
            canreflect = 1
            sleep(0.1)
            print("Your shield is shiny enough to reflect enemy attacks!")
        else:
            if monsteraction != "attacks":
                sleep(0.1)
                print(f"Your {inp} failed because the enemy didn't attack!")
        if inp in inventory:
            if inp == "BOMB":
                sleep(0.1)
                print("You throw a BOMB at the enemy!")
                sleep(0.1)
                print(f"BOOM!! You dealt {attack * 5} damage!")
                inventory.remove("BOMB")
                monsterhp -= attack * 5
            elif inp == "ROPE":
                sleep(0.1)
                print("You whip a ROPE at the enemy!")
                sleep(0.1)
                print(f"You dealt {attack * 0.5} damage!")
                monsterhp -= attack * 0.5
            elif inp == "LAMP OIL":
                sleep(0.1)
                print("You douse the enemy in LAMP OIL!")
                doused = 1
        if "COMBO" not in inp:
            combo = 0
        if monsterhp < 1:
            sleep(0.1)
            print("You win the bounty!")
            wonbounty = 1
            return
        turn()


def shop():
    inp = input(
        "Welcome to the Emporium!\n-----------\nSwords - A swordsman's best friend.\nShields - The ideal weapon for a defender.\nBows - The archer's passion.\nStaffs - To channel a mage's power.\nArmor - A must-have for adventurers.\nJewelry - Powerful buffs.\nUtility - Useful utility items.\n-----------\nEnter a category to see those items, or QUIT to leave the shop.\n> ")
    inp = inp.upper()
    if inp == "SWORDS":
        inp = input(
            "Swords\n-----------\nBASIC SWORD == 500 gold\n   Just your everyday sword.\nBROAD SWORD == 25000 gold\n   A larger, more powerful sword.\nPAPER SWORD == 125000 gold\n   Sharp.\nGLASS SWORD == 1000000 gold\n   Not quite a glass cannon.\nGOLDEN SWORD == 10000000 gold\n   A sharp and gold sword.\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "SHIELDS":
        inp = input(
            "Shields\n-----------\nBASIC SHIELD == 500 gold\n   Just your everyday shield.\nBANDED SHIELD == 25000 gold\n  A wooden sword banded with iron.\nSTEEL SHIELD == 125000 gold\n   A shield forged from hardened steel.\nTITANIUM SHIELD == 1000000 gold\n   A shield forged from the strongest titanium.\nGOLDEN SHIELD == 10000000 gold\n A powerful gold shield.\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "STAFFS":
        inp = input(
            "Staffs\n-----------\nBASIC STAFF == 500 gold\n   Just your everyday staff.\nOAK STAFF == 25000 gold\n   A staff crafted from fine oak.\nSPRUCE STAFF == 125000 gold\n   A staff crafted from fine spruce.\nEBONY STAFF == 1000000 gold\n   A staff crafted from fine ebony.\nGOLDEN STAFF == 10000000 gold\n   A mystical staff crafted from shiny gold.\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "BOWS":
        inp = input(
            "Bows\n-----------\nBASIC BOW == 500 gold\n   Just your everyday bow.\nSLENDER BOW == 25000 gold\n   A thin bow with whistling shots.\nSTRONG BOW == 125000 gold\n   A bow with the power of a giant.\nELDER BOW == 1000000 gold\n   The bow used by only the greatest archers.\nGOLDEN BOW == 10000000 gold\n   A elegant bow crafted from smooth gold.\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "ARMOR":
        inp = input(
            "Armor\n-----------\nBASIC ARMOR == 500 gold\n   Just your everyday armor.\nLEATHER ARMOR == 25000 gold\n   A sturdy set of armor made of thick leather.\nCOPPER ARMOR == 125000 gold\n   A strong set of armor made from malleable copper.\nTITANIUM ARMOR == 1000000 gold\n   An impenetrable layer of the strongest titanium.\nGOLDEN ARMOR == 10000000 gold\n   A glistening set of gold armor.\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "JEWELRY":
        inp = input(
            "Jewelry\n-----------\nPLAINS RING == 1000 gold\n   Gives a bonus while wearing in the PLAINS.\nMOUNTAIN RING == 35000 gold\n   Gives a bonus while wearing in the MOUNTAINS.\nCAVE RING == 200000 gold\n   Gives a bonus while wearing in the CAVES.\nGRAVEYARD RING == 200000 gold\n   Gives a bonus while wearing in the GRAVERYARD.\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "UTILITY":
        inp = input(
            "Utility\n-----------\nLAMP OIL == 100 rubees\n   For dark areas\nROPE == 10 rubees\n   suprisingly slimy.\nBOMB == 5 rubees\n   The enemies will be blown away!\nMYSTERY KEY == 500000 gold\n   found this in a dumpster. who knows what it does\n-----------\nSay BUY to buy an item, MENU to go back to the menu, or QUIT to leave.\n> ")
    elif inp == "QUIT":
        cmd()
    else:
        sleep(0.1)
        print("That isn't an option!")
        inp = 'MENU'
    inp = inp.upper()
    if inp == "MENU":
        shop()
    elif inp == "QUIT":
        return
    elif inp == "SELL":
        sell()
    elif inp == "BUY":
        buy()
    else:
        sleep(0.1)
        print("That isn't an option!")
        shop()


def sell():
    global inventory
    global totalgold
    global totalrubees
    global mountainsunlocked
    global shopitems
    global rubyitems
    sleep(0.1)
    print("What do you want to sell? (or QUIT)")
    sale = input("> ")
    sale = sale.upper()
    if sale in inventory:
        if sale in shopitems:
            price = ((shopitems[sale]) * 0.75)
            totalgold += price
            inventory.remove(sale)
            sleep(0.1)
            print("You sold your " + str(sale) + " for " + str(price) + " gold.")
        else:
            sleep(0.1)
            print("You can't sell items that cost rubees!")
    else:
        sleep(0.1)
        print("You don't have a " + sale + " to sell!")


def buy():
    global inventory
    global totalgold
    global totalrubees
    global mountainsunlocked
    global shopitems
    global rubyitems
    sleep(0.1)
    print("What do you want to buy? (or QUIT to leave the shop)")
    purchase = input("> ")
    purchase = purchase.upper()
    if purchase in shopitems:
        if purchase not in inventory:
            price = shopitems[purchase]
            if 1 == 1:
                if "RING" in str(purchase):
                    ringcheck = 0
                    if 'PLAINS RING' in inventory:
                        ringcheck += 1
                    if 'MOUNTAIN RING' in inventory:
                        ringcheck += 1
                    if 'CAVE RING' in inventory:
                        ringcheck += 1
                    if 'GRAVEYARD RING' in inventory:
                        ringcheck += 1
                    if ringcheck > 2:
                        sleep(0.1)
                        print("You have can only wear 3 rings! Sell one with SELL to buy another!")

                if "ARMOR" in str(purchase):
                    if "ARMOR" in str(inventory):
                        sleep(0.1)
                        print("You already have armor! Sell it with SELL!")
                        return
                elif "SWORD" in str(purchase):
                    if division == "SWORDSMAN":
                        if "SWORD" in str(inventory):
                            sleep(0.1)
                            print("You already have a sword! Sell it with SELL!")
                            return
                    else:
                        sleep(0.1)
                        print("Only swordsmen can wield swords!")
                        return
                elif "SHIELD" in str(purchase):
                    if "SHIELD" in str(inventory):
                        sleep(0.1)
                        print("You already have a shield! Sell it with SELL!")
                        return
                elif "BOW" in str(purchase):
                    if division == "ARCHER":
                        if "BOW" in str(inventory):
                            sleep(0.1)
                            print("You already have a bow! Sell it with SELL!")
                            return
                    else:
                        sleep(0.1)
                        print("Only archers can wield bows!")
                        return
                elif "STAFF" in str(purchase):
                    if division == "MAGE":
                        if "STAFF" in str(inventory):
                            sleep(0.1)
                            print("You already have a staff! Sell it with SELL!")
                            return
                    else:
                        sleep(0.1)
                        print("Only mages can wield staffs!")
                        return
                elif "ARMOR" in str(purchase):
                    if "ARMOR" in str(inventory):
                        sleep(0.1)
                        print("You already have armor! Sell it with SELL!")
                        return
                if price <= totalgold:
                    totalgold = totalgold - price
                    inventory += [purchase]
                    sleep(0.1)
                    print("you bought a " + str(purchase) + " for " + str(price) + " gold.")
                else:
                    sleep(0.1)
                    print("you need more gold! (" + str(totalgold) + "/" + str(price) + " gold)")
                    buy()
        else:
            sleep(0.1)
            print("you already have a " + str(purchase) + "!")
            buy()
    elif purchase in rubyitems:
        price = (rubyitems[purchase])
        if price <= totalrubees:
            if purchase not in inventory:
                inventory += [purchase]
                totalrubees = totalrubees - price
                sleep(0.1)
                print("you bought a " + str(purchase) + " for " + str(price) +
                      " rubees.")
                if purchase == 'BOMB':
                    sleep(0.1)
                    print("\nlaunch your bomb with 'BOOM'!")
                    if mountainsunlocked == 0:
                        sleep(0.1)
                        print(
                            "You look around, and notice some mountains blocked by a boulder! Go to the mountains with 'MOVE [AREA]'")
            else:
                sleep(0.1)
                print("you already have that item!")
                buy()
        else:
            sleep(0.1)
            print("you need more rubees to buy that!")
            buy()
    elif purchase == 'QUIT':
        sleep(0.1)
        print("you left the shop.")
        cmd()
    elif purchase == 'LEAVE':
        sleep(0.1)
        print("you left the shop.")
        cmd()
    elif purchase == 'SHOP':
        shop()
    else:
        sleep(0.1)
        print("you cant buy that! see what you can buy in SHOP")
        buy()


def hunt():
    global level
    global totalxp
    global totalgold
    global totalrubees
    global plainsmonsters
    global mountainmonsters
    global cavemonsters
    global graveyardmonsters
    global souls
    global area
    global lsc
    global currenthp
    global maxhp
    global tslh
    global defense
    updatestats()
    gainedxp = int(randrange(5, 10)) * level
    gainedgold = int(randrange(1, 69))
    extra = ''
    strength = defense + attack
    monsters = plainsmonsters
    if area == 'PLAINS':
        monsters = plainsmonsters
        currenthp = (currenthp - (randrange(100, 200) - strength))
        if 'PLAINS RING' in inventory:
            extra = "\nYour PLAINS RING gave you an extra 35 gold!"
            totalgold += 35
    if area == 'MOUNTAINS':
        gainedgold = round(gainedgold * 5)
        gainedxp = round(gainedxp * 5)
        monsters = mountainmonsters
        currenthp = (currenthp - (randrange(300, 600) - strength))
        if 'MOUNTAIN RING' in inventory:
            if 1 == randrange(1, 5):
                extra = "\nYour MOUNTAIN RING gave you a bonus ruby!"
                totalrubees += 1
    if area == 'CAVES':
        gainedgold = gainedgold * 25
        gainedxp = gainedxp * 25
        currenthp = (currenthp - (randrange(600, 1200) - strength))
        monsters = cavemonsters
        if 'CAVE RING' in inventory:
            if lsc == 10:
                extra = "Your CAVE RING lights the way.. You found another enemy!"
                currenthp = maxhp
                lsc = 0
                hunt()
        else:
            lsc += 1
    if area == 'GRAVEYARD':
        gainedgold = gainedgold * 125
        gainedxp = gainedxp * 125
        currenthp = (currenthp - (randrange(1200, 2400) - strength))
        monsters = graveyardmonsters
        if 'GRAVEYARD RING' in inventory:
            if souls < 25:
                extra = "Your GRAVEYARD RING sucks in the soul of the enemy."
                souls += 1
            if currenthp < 1:
                if souls > 9:
                    sleep(0.1)
                    print(
                        "You almost died fighting, but your GRAVEYARD RING used it's built up power to save you! You didn't lose anything.")
                    souls -= 10
                    return
    if currenthp < 1:
        lostgold = round(int(totalgold * 0.1))
        sleep(0.1)
        print("You encountered " + str(
            random.choice(monsters.split(','))) + ", but you didn't survive the fight! You lost " + str(
            lostgold) + " gold..")
        totalgold -= round(int(totalgold * 0.1))
        currenthp = 0
        return
    if currenthp > maxhp:
        currenthp = maxhp
    totalgold = gainedgold + totalgold
    totalxp = totalxp + gainedxp
    sleep(0.1)
    print("You encountered " + random.choice(monsters.split(',')) + " in the " + area +
          "! \nYou got " + str(gainedxp) + " xp (" + str(totalxp) +
          " total) and " + str(gainedgold) + " gold (" + str(totalgold) +
          " total)\nYou have " + str(currenthp) + "/" + str(maxhp) + " hp." + extra)
    neededxp = 50 * 2 ** (level - 1)
    if totalxp >= neededxp:
        level = level + 1
        sleep(0.1)
        print('you LEVELED UP to ' + str(level) + '. Your attack, defense, and hp increased!')
    if 1 == randrange(1, 5):
        totalrubees = totalrubees + 1
        sleep(0.1)
        print('you also got a ruby')


def bomb():
    if 'BOMB' in inventory:
        global level
    global totalxp
    global totalgold
    global totalrubees
    global plainsmonsters
    global mountainmonsters
    global cavemonsters
    global graveyardmonsters
    global area
    global dungdone
    monsters = plainsmonsters
    gainedxp = int(randrange(5, 10)) * level * 50
    gainedgold = int(randrange(1, 69)) * 50
    if area == 'MOUNTAINS':
        gainedgold = gainedgold * 5
        gainedxp = gainedxp * 5
        monsters = mountainmonsters
    if area == 'CAVES':
        gainedgold = gainedgold * 25
        gainedxp = gainedxp * 25
        monsters = cavemonsters
    if area == 'GRAVEYARD':
        gainedgold = gainedgold * 125
        gainedxp = gainedxp * 125
        monsters = cavemonsters
    totalgold = gainedgold + totalgold
    totalxp = totalxp + gainedxp
    inventory.remove('BOMB')
    sleep(0.1)
    print("You found an encampment of 50 monsters in the " + area + "!! \nYou got " + str(gainedxp) + " xp (" + str(
        totalxp) + " total) and " + str(gainedgold) + " gold (" + str(totalgold) + " total)")
    sleep(0.1)
    print("-----------")
    neededxp = 50 * 2 ** (level - 1)
    if totalxp >= neededxp:
        level = level + 1
        sleep(0.1)
        print('you LEVELED UP to ' + str(
            level) + ', you got stronger but the enemies are so easy to kill it doesnt matter')
        sleep(0.1)
        print("any rubees got destroyed by the bomb.")
    else:
        sleep(0.1)
        print("you don't have a bomb to ignite")


def cmd():
    global dragonbeaten
    global inventory
    global totalgold
    global totalrubees
    global level
    global totalxp
    global checkinv
    global area
    global mountainsunlocked
    global cavesunlocked
    global graveyardunlocked
    global maxhp
    global attack
    global defense
    global currenthp
    global subdivision
    global knownattacks
    global knowndefenses
    global dxp
    global dlevel
    sleep(0.1)
    print("-----------\nWhat would you like to do?")
    updatestats()
    inp = input("> ")
    inp = inp.upper().split()
    try:
        if inp[0] == "MOVE":
            if inp[1] != "PLAINS":
                if inp[1] != "MOUNTAINS":
                    if inp[1] != "CAVES":
                        if inp[1] != "GRAVEYARD":
                            sleep(0.1)
                            print("You can't go there!\nPlaces to go: PLAINS, MOUNTAINS, CAVES, GRAVEYARD")
    except:
        try:
            if inp[0] == "MOVE":
                sleep(0.1)
                print("The correct format is MOVE [PLACE]\nPlaces to go: PLAINS, MOUNTAINS, CAVES, GRAVEYARD")
                return
            else:
                sleep(0.1)
                print("There was problem processing your input, make sure to format correctly.")
                return
        except:
            sleep(0.1)
            print('that isnt a command!\n stuck? try "HELPME" ')
            return
    if inp[0] == 'HUNT':
        hunt()
    elif inp[0] == 'HELPME':
        sleep(0.1)
        print("-----------\ncommands : SAVE, HUNT, BOUNTY, SHOP, BUY, ME, MOVE, DUNGEON, UPDATENOTES")
        if 'BOMB' in inventory:
            sleep(0.1)
            print('let loose a bomb with "BOOM"!')
    elif inp[0] == 'SHOP':
        shop()
    elif inp[0] == 'UPDATENOTES':
        sleep(0.1)
        print("bv1.6.0 UPDATE NOTES:\
        - bounty is now finished, try it out!\
        - the game is now an app. duh. the repl.it in now depricated and not receiving updates.\
        - local save data is complete and will be cross-compatible with later game versions!\
        - many a bugfix")
    elif inp[0] == 'BUY':
        buy()
    elif inp[0] == 'BOUNTY':
        startbounty()
    elif inp[0] == 'MOVE':
        if inp[1] == 'PLAINS':
            if area != 'PLAINS':
                area = 'PLAINS'
            else:
                sleep(0.1)
                print("You are already in the plains!")
        elif inp[1] == 'MOUNTAINS':
            if mountainsunlocked == 1:
                if area != 'MOUNTAINS':
                    area = 'MOUNTAINS'
                    sleep(0.1)
                    print("You have moved to the mountains.")
                else:
                    sleep(0.1)
                    print("You are already in the mountains!")
            else:
                sleep(0.1)
                print("A boulder is blocking your path.. Seems like you need something to remove it.")
                if "BOMB" in inventory:
                    inp = input("Would you like to throw a bomb at it? (YES/NO)\n> ")
                    inp = inp.upper()
                    if inp == "YES":
                        sleep(0.1)
                        print("BOOM!!!")
                        inventory.remove('BOMB')
                        mountainsunlocked = 1
                        area = 'MOUNTAINS'
                        sleep(0.1)
                        print("You have moved to the mountains. (The monsters here give better rewards!)")
                        sleep(0.1)
                        print("You can now go to the caves.")
                    else:
                        sleep(0.1)
                        print("You decided not to throw the bomb.")
        elif inp[1] == 'CAVES':
            if cavesunlocked == 1:
                if area != 'CAVES':
                    area = 'CAVES'
                    sleep(0.1)
                    print("You have moved to the caves.")
                else:
                    sleep(0.1)
                    print("You are already in the caves!")
            else:
                if mountainsunlocked == 1:
                    sleep(0.1)
                    print(
                        "You try to move into the caves..\nThe passage is too dark! There seem to be unlit lamps, but they have no fuel.")
                    if "LAMP OIL" in inventory:
                        inp = input("Would you like to use your lamp oil? (YES/NO)\n> ")
                        inp = inp.upper()
                        if inp == "YES":
                            sleep(0.1)
                            print("You oil and light the lamps.")
                            inventory.remove('LAMP OIL')
                            cavesunlocked = 1
                            area = 'CAVES'
                            sleep(0.1)
                            print(
                                "You have moved to the caves. (The monsters here give much better rewards!\nYou can now go to the graveyard.")
                        else:
                            sleep(0.1)
                            print("You decided not to use the lamp oil.")
                else:
                    sleep(0.1)
                    print("You need to get to the mountains first to get to the caves!")
        elif inp[1] == 'GRAVEYARD':
            if graveyardunlocked == 1:
                if area != 'GRAVEYARD':
                    area = 'GRAVEYARD'
                    sleep(0.1)
                    print("You have moved to the graveyard.")
                else:
                    sleep(0.1)
                    print("You are already in the graveyard!")
            else:
                if cavesunlocked == 1:
                    sleep(0.1)
                    print("You try to exit the caves..\nThe way up is too steep! You will need something to scale it with.")
                    if "ROPE" in inventory:
                        inp = input("Would you like to use your rope? (YES/NO)\n> ")
                        inp = inp.upper()
                        if inp == "YES":
                            sleep(0.1)
                            print("You scale the slope with your rope.")
                            inventory.remove('ROPE')
                            graveyardunlocked = 1
                            area = 'GRAVEYARD'
                            sleep(0.1)
                            print("You have moved to the graveyard. (The monsters here give way better rewards!")
                        else:
                            sleep(0.1)
                            print("You decided not to use your rope.")
                else:
                    sleep(0.1)
                    print("You need to get to the caves first to get to the graveyard!")
    elif inp[0] == 'DUNGEON':
        sleep(0.1)
        print("dungeons have been removed for a HUGE REVAMP coming soon!")
    elif inp[0] == 'BOOM':
        bomb()
    elif inp[0] == 'DEVTOOLS':
            level = int(input("level: "))
            totalxp = int(input("totalxp: "))
            totalgold = int(input("totalgold: "))
            totalrubees = int(input("totalrubees: "))
            dxp = int(input("dxp: "))
    elif inp[0] == 'ME':
        updatestats()
        if inventory == checkinv:
            sleep(0.1)
            print(f"{subdivision}: Division level {dlevel}, {dxp} division xp")
            sleep(0.1)
            print("Attacks: " + str(knownattacks))
            sleep(0.1)
            print("Defenses: " + str(knowndefenses))
            sleep(0.1)
            print("Attacks: " + str(knownattacks))
            sleep(0.1)
            print("Defenses: " + str(knowndefenses))
            sleep(0.1)
            print("Level: " + str(level))
            sleep(0.1)
            print("Hp: " + str(currenthp) + "/" + str(maxhp))
            sleep(0.1)
            print("Attack: " + str(attack))
            sleep(0.1)
            print("Defense: " + str(defense))
            sleep(0.1)
            print("Area: " + str(area))
            sleep(0.1)
            print("Gold: " + str(totalgold))
            sleep(0.1)
            print("Rubees: " + str(totalrubees))
            sleep(0.1)
            print("you have nothing in your inventory")
        else:
            sleep(0.1)
            print(f"{subdivision}: Division level {dlevel}, {dxp} division xp")
            sleep(0.1)
            print("Attacks: " + str(knownattacks))
            sleep(0.1)
            print("Defenses: " + str(knowndefenses))
            sleep(0.1)
            print("Level: " + str(level))
            sleep(0.1)
            print("Area: " + str(area))
            sleep(0.1)
            print("Gold: " + str(totalgold))
            sleep(0.1)
            print("Rubees: " + str(totalrubees))
            sleep(0.1)
            print("Your inventory:\n" + str(inventory))
    elif inp[0] == "SAVE":
        save()
    else:
        sleep(0.1)
        print('that isnt a command! (try "HELPME") ')


while 1 == 1:
    cmd()
